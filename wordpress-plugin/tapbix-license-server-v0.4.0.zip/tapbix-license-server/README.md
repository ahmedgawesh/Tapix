# TapBix License Server v0.4.0

Secure offline-first license issuing and device activation server for TapBix Windows and Linux.

## Supported WooCommerce SKUs

| SKU | Plan | Devices | Expiry |
| --- | --- | ---: | --- |
| `TAPBIX-DESKTOP-MONTHLY-1D` | Monthly | 1 | One calendar month from issue or renewal |
| `TAPBIX-DESKTOP-ANNUAL-1D` | Annual | 1 | One calendar year from issue or renewal |
| `TAPBIX-DESKTOP-LIFETIME-1D` | Lifetime | 1 | Lifetime |
| `TAPBIX-WIN-LIFE-1D` | Lifetime (legacy) | 1 | Lifetime |

All supported SKUs issue `tapbix-desktop` licenses that work on both Windows and Linux. License issuance remains idempotent through the existing unique `(order_id, order_item_id)` database key.

## New in v0.4.0

- Adds monthly, annual, and current lifetime desktop SKUs while preserving the legacy lifetime SKU.
- Displays license expiry in My Account, customer license emails, and the WordPress admin table.
- Suspends existing licenses after a full order refund, a full refund of the licensed line item, or cancellation of an already licensed order.
- Never deletes licenses or activations for refund/cancellation events and records each automatic suspension in the license log.
- Extends an existing monthly/annual license for safely identified renewal orders instead of issuing a second unrelated license.
- Preserves REST schema 2, activation tokens, RSA keys, tables, license keys, device activations, the 7-day offline lease, and the 24-hour revalidation interval.

## Upgrade

1. Back up the WordPress database and the current plugin ZIP.
2. Upload this ZIP from WordPress -> Plugins -> Add Plugin -> Upload Plugin.
3. Choose **Replace current with uploaded**.
4. Open WordPress Admin -> TapBix Licenses to run the non-destructive version check.
5. Confirm the displayed public key is unchanged and still matches the key embedded in TapBix Desktop.

The upgrade does not rename or remove tables and does not modify existing licenses or activations. Never delete the `tapbix_license_private_key` or `tapbix_license_public_key` options. If only one half of the RSA key pair is present, v0.4.0 deliberately refuses to generate a replacement and displays an administrator warning so the missing key can be restored from backup.

## Refund and cancellation policy

- A full order refund suspends every TapBix license associated with that order.
- A partial order refund suspends a license only when the associated licensed line item has been fully refunded by quantity or line total.
- Cancelling an order after issuance suspends its licenses.
- Suspensions are idempotent, preserve activation history, and can still be reviewed or manually changed by an administrator.

## Renewal integration

When WooCommerce Subscriptions is active and exposes `wcs_order_contains_renewal()` plus `wcs_get_subscriptions_for_renewal_order()`, v0.4.0 resolves the original subscription order and extends the matching monthly/annual license. The renewal order stores the renewed license IDs and a processed marker in WooCommerce order meta so the existing payment-complete and order-completed hooks cannot extend the same renewal twice.

WooCommerce Subscriptions is not required. Without an identifiable renewal provider, monthly and annual SKU purchases are treated as new purchases. Another recurring-payment plugin can safely identify a renewal by returning the original paid order ID(s) through:

```php
add_filter('tapbix_license_renewal_source_order_ids', function ($source_order_ids, $renewal_order) {
    // Return an array of original WooCommerce order IDs only when this is
    // definitely a paid renewal. Return null for ordinary purchases.
    return $source_order_ids;
}, 10, 2);
```

The payment/subscription component remains responsible for charging customers and creating paid renewal orders. TapBix License Server only extends a license after an existing paid-order hook runs.

## Desktop protocol compatibility

- `POST /wp-json/tapbix/v1/activate`
  - Input: `license_key`, `device_id`, `device_name`, `platform`, `app_version`
  - Output: `ok`, `license_id`, `activation_token`, `license`
- `POST /wp-json/tapbix/v1/validate`
  - Input: `license_id`, `activation_token`, `device_id`, `platform`, `app_version`
  - Output: `ok`, `license`

The signed payload remains schema 2 with app ID `com.tapix.pos`. The RSA private key never leaves WordPress; the Flutter application contains only the public key.

## Linux end-to-end test

1. Open WordPress Admin -> TapBix Licenses.
2. Click **Create Test License**.
3. Copy the generated TBX key from the TEST row.
4. If the internal activation test already consumed its device slot, click **Reset devices**.
5. Activate TapBix Linux with the key, then close and reopen the app.
6. Confirm the app loads from the signed offline lease.
7. Use **Revoke** in WordPress and trigger online validation to confirm revocation handling.

The internal test verifies RSA-SHA256, the activation token, and the unchanged desktop schema-2 fields.
