Tapix Language Router 1.2.4

Fixes and improvements:
- Fully localizes the WooCommerce My Account dashboard greeting and dashboard description in Arabic and French.
- Supports the current WooCommerce dashboard strings that contain inline account links.
- Adds a fallback for minor WooCommerce dashboard wording changes.
- Localizes the My Account page title in Arabic and French.
- Keeps all previous front-end-only language routing, Shop, Cart, Checkout, product and wp-admin safety fixes.
