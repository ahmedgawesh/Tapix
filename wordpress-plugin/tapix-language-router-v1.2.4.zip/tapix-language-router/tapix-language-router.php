<?php
/**
 * Plugin Name: Tapix Language Router
 * Description: Keeps the selected Tapix Solutions language across pages and localizes internal navigation for English, Arabic and French.
 * Version: 1.2.4
 * Author: Tapix Solutions
 * Requires at least: 6.0
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

final class Tapix_Language_Router {
    const COOKIE = 'tbx_lang';
    const VERSION = '1.2.4';

    private static $languages = array( 'en', 'ar', 'fr' );

    private static $routes = array(
        'home' => array(
            'en' => '/',
            'ar' => '/ar/',
            'fr' => '/fr/',
        ),
        'tapbix' => array(
            'en' => '/tapbix/',
            'ar' => '/ar/tapbix/',
            'fr' => '/fr/tapbix/',
        ),
        'services' => array(
            'en' => '/services/',
            'ar' => '/ar/services/',
            'fr' => '/fr/services/',
        ),
        'features' => array(
            'en' => '/features/',
            'ar' => '/ar/features/',
            'fr' => '/fr/features/',
        ),
        'pricing' => array(
            'en' => '/pricing/',
            'ar' => '/ar/pricing/',
            'fr' => '/fr/pricing/',
        ),
        'download' => array(
            'en' => '/download/',
            'ar' => '/ar/download/',
            'fr' => '/fr/download/',
        ),
        'faq' => array(
            'en' => '/faq/',
            'ar' => '/ar/faq/',
            'fr' => '/fr/faq/',
        ),
        'support' => array(
            'en' => '/support/',
            'ar' => '/ar/support/',
            'fr' => '/fr/support/',
        ),
        'contact' => array(
            'en' => '/contact/',
            'ar' => '/ar/contact/',
            'fr' => '/fr/contact/',
        ),
        'privacy' => array(
            'en' => '/privacy-policy/',
            'ar' => '/ar/privacy-policy/',
            'fr' => '/fr/privacy-policy/',
        ),
        'refund' => array(
            'en' => '/refund_returns/',
            'ar' => '/ar/refund-policy/',
            'fr' => '/fr/refund-policy/',
        ),
        'terms' => array(
            'en' => '/terms-and-conditions/',
            'ar' => '/ar/terms-and-conditions/',
            'fr' => '/fr/terms-and-conditions/',
        ),
    );

    public static function boot() {
        add_action( 'init', array( __CLASS__, 'capture_language' ), 0 );
        add_action( 'init', array( __CLASS__, 'maybe_switch_locale' ), 1 );
        add_action( 'template_redirect', array( __CLASS__, 'redirect_to_selected_language' ), 1 );

        add_filter( 'wp_nav_menu_objects', array( __CLASS__, 'localize_menu_items' ), 20, 2 );
        add_filter( 'the_content', array( __CLASS__, 'localize_content_links' ), 99 );
        add_filter( 'widget_text_content', array( __CLASS__, 'localize_content_links' ), 99 );
        add_filter( 'language_attributes', array( __CLASS__, 'language_attributes' ), 20, 2 );
        add_filter( 'body_class', array( __CLASS__, 'body_class' ) );
        add_filter( 'the_title', array( __CLASS__, 'localize_special_page_titles' ), 100, 2 );
        add_filter( 'woocommerce_page_title', array( __CLASS__, 'localize_shop_page_title' ), 100 );
        add_filter( 'woocommerce_get_breadcrumb', array( __CLASS__, 'localize_woocommerce_breadcrumbs' ), 100, 2 );
        add_filter( 'woocommerce_product_get_name', array( __CLASS__, 'localize_product_name' ), 100, 2 );
        add_filter( 'woocommerce_product_variation_get_name', array( __CLASS__, 'localize_product_name' ), 100, 2 );
        add_filter( 'get_term', array( __CLASS__, 'localize_product_category_term' ), 100, 2 );
        add_filter( 'woocommerce_short_description', array( __CLASS__, 'localize_product_short_description' ), 80 );
        add_filter( 'the_content', array( __CLASS__, 'localize_product_long_description' ), 80 );

        // WooCommerce localization across account, cart, checkout and shop.
        add_filter( 'woocommerce_get_terms_and_conditions_page_id', array( __CLASS__, 'localized_terms_page_id' ), 100 );
        add_filter( 'privacy_policy_url', array( __CLASS__, 'localized_privacy_url' ), 100, 2 );
        add_filter( 'woocommerce_get_privacy_policy_text', array( __CLASS__, 'localized_privacy_policy_text' ), 100, 2 );
        add_filter( 'woocommerce_get_terms_and_conditions_checkbox_text', array( __CLASS__, 'localized_terms_checkbox_text' ), 100 );
        add_filter( 'woocommerce_gateway_title', array( __CLASS__, 'localized_gateway_title' ), 100, 2 );
        add_filter( 'woocommerce_gateway_description', array( __CLASS__, 'localized_gateway_description' ), 100, 2 );
        add_filter( 'wc_add_to_cart_message_html', array( __CLASS__, 'localized_add_to_cart_message' ), 100, 3 );

        // WooCommerce My Account localization.
        add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'localize_account_menu' ), 100 );
        add_filter( 'gettext', array( __CLASS__, 'localize_gettext' ), 100, 3 );
        add_filter( 'ngettext', array( __CLASS__, 'localize_ngettext' ), 100, 5 );
        add_shortcode( 'tapix_account_intro', array( __CLASS__, 'account_intro_shortcode' ) );
        add_shortcode( 'tapix_cart_intro', array( __CLASS__, 'cart_intro_shortcode' ) );
        add_shortcode( 'tapix_checkout_intro', array( __CLASS__, 'checkout_intro_shortcode' ) );
        add_action( 'wp_head', array( __CLASS__, 'account_styles' ), 100 );
        add_action( 'wp_head', array( __CLASS__, 'commerce_styles' ), 100 );

        add_action( 'wp_footer', array( __CLASS__, 'switcher_script' ), 100 );
    }

    private static function normalize_path( $path ) {
        $path = '/' . ltrim( (string) $path, '/' );
        if ( '/' !== $path ) {
            $path = trailingslashit( $path );
        }
        return $path;
    }

    private static function request_path() {
        $uri = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/';
        $path = wp_parse_url( $uri, PHP_URL_PATH );
        return self::normalize_path( $path ? $path : '/' );
    }

    private static function key_from_path( $path ) {
        $path = self::normalize_path( $path );
        foreach ( self::$routes as $key => $langs ) {
            foreach ( $langs as $route ) {
                if ( self::normalize_path( $route ) === $path ) {
                    return $key;
                }
            }
        }
        return '';
    }

    private static function current_language() {
        if ( isset( $_GET['tbx_lang'] ) ) {
            $lang = sanitize_key( wp_unslash( $_GET['tbx_lang'] ) );
            if ( in_array( $lang, self::$languages, true ) ) {
                return $lang;
            }
        }

        $path = self::request_path();
        if ( 0 === strpos( $path, '/ar/' ) || '/ar/' === $path ) {
            return 'ar';
        }
        if ( 0 === strpos( $path, '/fr/' ) || '/fr/' === $path ) {
            return 'fr';
        }

        if ( isset( $_COOKIE[ self::COOKIE ] ) ) {
            $lang = sanitize_key( wp_unslash( $_COOKIE[ self::COOKIE ] ) );
            if ( in_array( $lang, self::$languages, true ) ) {
                return $lang;
            }
        }

        return 'en';
    }

    private static function set_language_cookie( $lang ) {
        if ( ! in_array( $lang, self::$languages, true ) || headers_sent() ) {
            return;
        }

        $expire = time() + YEAR_IN_SECONDS;
        $secure = is_ssl();

        if ( PHP_VERSION_ID >= 70300 ) {
            setcookie(
                self::COOKIE,
                $lang,
                array(
                    'expires'  => $expire,
                    'path'     => '/',
                    'domain'   => '',
                    'secure'   => $secure,
                    'httponly' => false,
                    'samesite' => 'Lax',
                )
            );
        } else {
            setcookie( self::COOKIE, $lang, $expire, '/; samesite=Lax', '', $secure, false );
        }

        $_COOKIE[ self::COOKIE ] = $lang;
    }

    public static function maybe_switch_locale() {
        if ( is_admin() ) {
            return;
        }

        $lang = self::current_language();
        $locale = '';
        if ( 'ar' === $lang ) {
            $locale = 'ar';
        } elseif ( 'fr' === $lang ) {
            $locale = 'fr_FR';
        }

        if ( $locale && function_exists( 'switch_to_locale' ) ) {
            switch_to_locale( $locale );
        }
    }

    public static function capture_language() {
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() ) {
            return;
        }

        if ( isset( $_GET['tbx_lang'] ) ) {
            $lang = sanitize_key( wp_unslash( $_GET['tbx_lang'] ) );
            if ( in_array( $lang, self::$languages, true ) ) {
                self::set_language_cookie( $lang );
                return;
            }
        }

        $path = self::request_path();
        if ( 0 === strpos( $path, '/ar/' ) || '/ar/' === $path ) {
            self::set_language_cookie( 'ar' );
        } elseif ( 0 === strpos( $path, '/fr/' ) || '/fr/' === $path ) {
            self::set_language_cookie( 'fr' );
        }
    }

    public static function redirect_to_selected_language() {
        if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || is_feed() || is_trackback() ) {
            return;
        }

        if ( isset( $_SERVER['REQUEST_METHOD'] ) && 'GET' !== strtoupper( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_METHOD'] ) ) ) ) {
            return;
        }

        $path = self::request_path();
        $key  = self::key_from_path( $path );
        if ( ! $key ) {
            return;
        }

        $lang   = self::current_language();
        $target = isset( self::$routes[ $key ][ $lang ] ) ? self::$routes[ $key ][ $lang ] : self::$routes[ $key ]['en'];
        $target = self::normalize_path( $target );

        $has_lang_query = isset( $_GET['tbx_lang'] );
        if ( $path !== $target || $has_lang_query ) {
            wp_safe_redirect( home_url( $target ), 302 );
            exit;
        }
    }

    private static function localized_url_for_path( $path, $lang ) {
        $key = self::key_from_path( $path );
        if ( ! $key || empty( self::$routes[ $key ][ $lang ] ) ) {
            return '';
        }
        return home_url( self::$routes[ $key ][ $lang ] );
    }

    private static function translate_menu_title( $key, $lang, $fallback ) {
        $labels = array(
            'en' => array(
                'home' => 'Home', 'tapbix' => 'TapBix', 'services' => 'Services', 'features' => 'Features',
                'pricing' => 'Pricing', 'download' => 'Download', 'faq' => 'FAQ', 'support' => 'Support',
                'contact' => 'Contact', 'privacy' => 'Privacy', 'refund' => 'Refund Policy', 'terms' => 'Terms',
            ),
            'ar' => array(
                'home' => 'الرئيسية', 'tapbix' => 'TapBix', 'services' => 'الخدمات', 'features' => 'المزايا',
                'pricing' => 'الأسعار', 'download' => 'التحميل', 'faq' => 'الأسئلة الشائعة', 'support' => 'الدعم',
                'contact' => 'اتصل بنا', 'privacy' => 'سياسة الخصوصية', 'refund' => 'سياسة الاسترجاع', 'terms' => 'الشروط والأحكام',
            ),
            'fr' => array(
                'home' => 'Accueil', 'tapbix' => 'TapBix', 'services' => 'Services', 'features' => 'Fonctionnalités',
                'pricing' => 'Tarifs', 'download' => 'Téléchargement', 'faq' => 'FAQ', 'support' => 'Support',
                'contact' => 'Contact', 'privacy' => 'Politique de confidentialité', 'refund' => 'Politique de remboursement', 'terms' => 'Conditions générales',
            ),
        );

        return isset( $labels[ $lang ][ $key ] ) ? $labels[ $lang ][ $key ] : $fallback;
    }

    public static function localize_menu_items( $items, $args ) {
        if ( is_admin() ) {
            return $items;
        }

        $lang = self::current_language();

        $site_host = strtolower( (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST ) );

        foreach ( $items as $item ) {
            $url_path = wp_parse_url( $item->url, PHP_URL_PATH );
            $url_host = strtolower( (string) wp_parse_url( $item->url, PHP_URL_HOST ) );

            // Demo lives on its own subdomain. Never rewrite it as the site home.
            $plain_title = strtolower( trim( wp_strip_all_tags( $item->title ) ) );
            if ( 'demo.tapixsolutions.com' === $url_host || in_array( $plain_title, array( 'demo', 'démo', 'العرض التجريبي' ), true ) ) {
                $item->url   = 'https://demo.tapixsolutions.com/';
                $item->title = ( 'ar' === $lang ) ? 'العرض التجريبي' : ( ( 'fr' === $lang ) ? 'Démo' : 'Demo' );
                continue;
            }

            $is_internal = ( '' === $url_host || $url_host === $site_host );

            if ( $is_internal && $url_path ) {
                $key = self::key_from_path( $url_path );
                if ( $key ) {
                    $localized = self::localized_url_for_path( $url_path, $lang );
                    if ( $localized ) {
                        $item->url = $localized;
                    }
                    $item->title = self::translate_menu_title( $key, $lang, $item->title );
                    continue;
                }
            }

            $title = strtolower( trim( wp_strip_all_tags( $item->title ) ) );
            if ( 'cart' === $title || 'panier' === $title || 'سلة المشتريات' === $title || 'السلة' === $title ) {
                $item->title = ( 'ar' === $lang ) ? 'سلة المشتريات' : ( ( 'fr' === $lang ) ? 'Panier' : 'Cart' );
                $item->url   = home_url( '/cart/' );
            } elseif ( 'my account' === $title || 'mon compte' === $title || 'حسابي' === $title ) {
                $item->title = ( 'ar' === $lang ) ? 'حسابي' : ( ( 'fr' === $lang ) ? 'Mon compte' : 'My Account' );
            } elseif ( 'demo' === $title || 'démo' === $title || 'العرض التجريبي' === $title ) {
                $item->title = ( 'ar' === $lang ) ? 'العرض التجريبي' : ( ( 'fr' === $lang ) ? 'Démo' : 'Demo' );
            }
        }

        return $items;
    }

    public static function localize_content_links( $content ) {
        if ( is_admin() || ! is_string( $content ) || '' === $content ) {
            return $content;
        }

        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $content;
        }

        foreach ( self::$routes as $key => $langs ) {
            if ( 'home' === $key ) {
                continue;
            }

            $en_abs = home_url( $langs['en'] );
            $to_abs = home_url( $langs[ $lang ] );
            $content = str_replace( $en_abs, $to_abs, $content );
            $content = str_replace( 'href="' . $langs['en'] . '"', 'href="' . $langs[ $lang ] . '"', $content );
            $content = str_replace( "href='" . $langs['en'] . "'", "href='" . $langs[ $lang ] . "'", $content );
        }

        $home = home_url( '/' );
        $localized_home = home_url( self::$routes['home'][ $lang ] );
        $content = preg_replace(
            '#href=([\"\'])' . preg_quote( $home, '#' ) . '\1#',
            'href="$localized_home"',
            $content
        );

        return $content;
    }

    public static function language_attributes( $output, $doctype ) {
        // Never alter wp-admin document language/direction. Front-end only.
        if ( is_admin() ) {
            return $output;
        }

        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            return 'lang="ar" dir="rtl"';
        }
        if ( 'fr' === $lang ) {
            return 'lang="fr-FR" dir="ltr"';
        }
        return 'lang="en-US" dir="ltr"';
    }

    public static function body_class( $classes ) {
        $classes[] = 'tapix-lang-' . self::current_language();
        return $classes;
    }



    public static function localize_special_page_titles( $title, $post_id = 0 ) {
        if ( is_admin() || ! $post_id || ! function_exists( 'wc_get_page_id' ) ) {
            return $title;
        }

        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $title;
        }

        if ( (int) $post_id === (int) wc_get_page_id( 'cart' ) ) {
            return ( 'ar' === $lang ) ? 'سلة المشتريات' : 'Panier';
        }
        if ( (int) $post_id === (int) wc_get_page_id( 'checkout' ) ) {
            return ( 'ar' === $lang ) ? 'إتمام الطلب' : 'Paiement';
        }
        if ( (int) $post_id === (int) wc_get_page_id( 'shop' ) ) {
            return ( 'ar' === $lang ) ? 'المتجر' : 'Boutique';
        }
        if ( (int) $post_id === (int) wc_get_page_id( 'myaccount' ) ) {
            return ( 'ar' === $lang ) ? 'حسابي' : 'Mon compte';
        }

        if ( 'product' === get_post_type( $post_id ) ) {
            $sku = (string) get_post_meta( $post_id, '_sku', true );
            if ( 'TAPBIX-DESKTOP-LIFETIME-1D' === $sku || false !== stripos( $title, 'TapBix Desktop POS' ) ) {
                return ( 'ar' === $lang )
                    ? 'TapBix Desktop POS & ERP — ترخيص مدى الحياة — جهاز واحد'
                    : 'TapBix Desktop POS & ERP — Licence à vie — 1 appareil';
            }
            if ( 'TAPBIX-DESKTOP-ADD-DEVICE' === $sku || false !== stripos( $title, 'TapBix Additional Desktop Device' ) ) {
                return ( 'ar' === $lang )
                    ? 'TapBix — جهاز مكتبي إضافي'
                    : 'TapBix — Appareil de bureau supplémentaire';
            }
        }
        return $title;
    }

    public static function localize_shop_page_title( $title ) {
        if ( is_admin() ) {
            return $title;
        }
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            return 'المتجر';
        }
        if ( 'fr' === $lang ) {
            return 'Boutique';
        }
        return $title;
    }

    public static function localize_woocommerce_breadcrumbs( $crumbs, $breadcrumb ) {
        if ( is_admin() ) {
            return $crumbs;
        }
        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $crumbs;
        }
        foreach ( $crumbs as &$crumb ) {
            if ( empty( $crumb[0] ) ) {
                continue;
            }
            if ( 'Home' === $crumb[0] ) {
                $crumb[0] = ( 'ar' === $lang ) ? 'الرئيسية' : 'Accueil';
                if ( isset( $crumb[1] ) ) {
                    $crumb[1] = home_url( self::$routes['home'][ $lang ] );
                }
            } elseif ( 'Shop' === $crumb[0] ) {
                $crumb[0] = ( 'ar' === $lang ) ? 'المتجر' : 'Boutique';
            } elseif ( false !== stripos( $crumb[0], 'TapBix Desktop POS' ) ) {
                $crumb[0] = ( 'ar' === $lang )
                    ? 'TapBix Desktop POS & ERP — ترخيص مدى الحياة — جهاز واحد'
                    : 'TapBix Desktop POS & ERP — Licence à vie — 1 appareil';
            } elseif ( false !== stripos( $crumb[0], 'TapBix Additional Desktop Device' ) ) {
                $crumb[0] = ( 'ar' === $lang )
                    ? 'TapBix — جهاز مكتبي إضافي'
                    : 'TapBix — Appareil de bureau supplémentaire';
            }
        }
        unset( $crumb );
        return $crumbs;
    }

    public static function localize_product_name( $name, $product ) {
        if ( is_admin() || ! is_object( $product ) ) {
            return $name;
        }
        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $name;
        }
        $sku = method_exists( $product, 'get_sku' ) ? (string) $product->get_sku() : '';
        if ( 'TAPBIX-DESKTOP-LIFETIME-1D' === $sku || false !== stripos( $name, 'TapBix Desktop POS' ) ) {
            return ( 'ar' === $lang )
                ? 'TapBix Desktop POS & ERP — ترخيص مدى الحياة — جهاز واحد'
                : 'TapBix Desktop POS & ERP — Licence à vie — 1 appareil';
        }
        if ( 'TAPBIX-DESKTOP-ADD-DEVICE' === $sku || false !== stripos( $name, 'TapBix Additional Desktop Device' ) ) {
            return ( 'ar' === $lang )
                ? 'TapBix — جهاز مكتبي إضافي'
                : 'TapBix — Appareil de bureau supplémentaire';
        }
        return $name;
    }

    private static function is_main_tapbix_product() {
        if ( ! function_exists( 'is_product' ) || ! is_product() ) {
            return false;
        }
        $post_id = get_queried_object_id();
        if ( ! $post_id ) {
            return false;
        }
        $sku = (string) get_post_meta( $post_id, '_sku', true );
        return 'TAPBIX-DESKTOP-LIFETIME-1D' === $sku || 14 === (int) $post_id;
    }

    public static function localize_product_short_description( $content ) {
        if ( is_admin() || ! self::is_main_tapbix_product() ) {
            return $content;
        }
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            return '<p><strong>TapBix POS &amp; ERP لسطح المكتب</strong> هو نظام متكامل لنقاط البيع وإدارة الأعمال يعمل بأسلوب Offline-first ومصمم لمتاجر التجزئة والمشروعات الصغيرة. يمكنك إدارة المبيعات والمخزون والعملاء والموردين والموظفين والمصروفات والتقارير وطباعة الباركود والصلاحيات والعروض الترويجية ودورة حياة الشيكات من تطبيق واحد.</p><p><strong>الترخيص:</strong> مدى الحياة<br><strong>الأجهزة:</strong> جهاز مكتبي واحد<br><strong>الإنترنت:</strong> غير مطلوب للتشغيل اليومي بعد التفعيل</p>';
        }
        if ( 'fr' === $lang ) {
            return '<p><strong>TapBix POS &amp; ERP pour ordinateur</strong> est une solution complète de point de vente et de gestion d’entreprise, conçue en mode offline-first pour les détaillants et les petites entreprises. Gérez les ventes, le stock, les clients, les fournisseurs, les employés, les dépenses, les rapports, les codes-barres, les autorisations, les promotions et le suivi du cycle de vie des chèques depuis une seule application.</p><p><strong>Licence :</strong> à vie<br><strong>Appareils :</strong> 1 ordinateur<br><strong>Internet :</strong> non requis pour l’utilisation quotidienne après activation</p>';
        }
        return $content;
    }

    public static function localize_product_long_description( $content ) {
        if ( is_admin() || ! self::is_main_tapbix_product() ) {
            return $content;
        }
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            return '<p><strong>TapBix POS &amp; ERP لسطح المكتب</strong> يوفر الأدوات الأساسية لإدارة نشاطك من مكان واحد.</p><p><strong>أهم المزايا:</strong></p><p>• مبيعات وفواتير POS سريعة<br>• إدارة المنتجات والمخزون<br>• إدارة العملاء والموردين<br>• المشتريات والمرتجعات<br>• مرتجعات المبيعات<br>• إدارة الموظفين والصلاحيات<br>• متابعة المصروفات<br>• التقارير وتحليلات الأعمال<br>• إنشاء وطباعة الباركود<br>• سجل العمليات وصلاحيات المستخدمين<br>• دعم الشبكة المحلية لأكثر من جهاز كاشير<br>• <strong>إدارة العروض والترويجات</strong><br>• <strong>متابعة دورة حياة الشيكات</strong><br>• واجهة بالعربية والإنجليزية والفرنسية<br>• تشغيل Offline-first</p><p><strong>العروض والترويجات:</strong> أنشئ وأدر العروض الترويجية مباشرة داخل TapBix لدعم حملات المتجر والمبيعات.</p><p><strong>متابعة الشيكات:</strong> نظّم حالات الشيكات خلال دورة حياتها بدل الاعتماد على سجلات يدوية متفرقة.</p><p>يتضمن هذا المنتج <strong>ترخيصًا مدى الحياة لجهاز مكتبي واحد</strong>.</p><p>بعد الشراء سيظهر ترخيص TapBix داخل حسابك ويمكن تفعيله من تطبيق سطح المكتب.</p>';
        }
        if ( 'fr' === $lang ) {
            return '<p><strong>TapBix POS &amp; ERP pour ordinateur</strong> réunit les outils essentiels pour gérer votre activité depuis un seul endroit.</p><p><strong>Fonctionnalités principales :</strong></p><p>• Ventes POS et facturation rapides<br>• Gestion des produits et du stock<br>• Gestion des clients et fournisseurs<br>• Achats et retours<br>• Retours de ventes<br>• Gestion des employés et autorisations<br>• Suivi des dépenses<br>• Rapports et analyses de l’activité<br>• Génération et impression de codes-barres<br>• Journal d’audit et droits utilisateurs<br>• Prise en charge du réseau local pour plusieurs postes de caisse<br>• <strong>Gestion des offres et promotions</strong><br>• <strong>Suivi du cycle de vie des chèques</strong><br>• Interface en arabe, anglais et français<br>• Fonctionnement offline-first</p><p><strong>Offres et promotions :</strong> créez et gérez des promotions directement dans TapBix pour soutenir les campagnes et l’activité commerciale.</p><p><strong>Suivi des chèques :</strong> organisez les statuts des chèques tout au long de leur cycle de vie au lieu de dépendre de registres manuels dispersés.</p><p>Ce produit comprend une <strong>licence à vie pour un ordinateur</strong>.</p><p>Après l’achat, votre licence TapBix sera disponible dans votre compte et pourra être activée dans l’application de bureau.</p>';
        }
        return $content;
    }

    public static function localize_product_category_term( $term, $taxonomy ) {
        if ( is_admin() || ! is_object( $term ) || 'product_cat' !== $taxonomy ) {
            return $term;
        }
        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $term;
        }
        if ( isset( $term->slug ) && 'software' === $term->slug ) {
            $term = clone $term;
            $term->name = ( 'ar' === $lang ) ? 'البرمجيات' : 'Logiciels';
        }
        return $term;
    }

    private static function page_id_from_route( $key, $lang ) {
        if ( empty( self::$routes[ $key ][ $lang ] ) ) {
            return 0;
        }
        $path = trim( self::$routes[ $key ][ $lang ], '/' );
        if ( '' === $path ) {
            return (int) get_option( 'page_on_front' );
        }
        $page = get_page_by_path( $path, OBJECT, 'page' );
        return $page ? (int) $page->ID : 0;
    }

    public static function localized_terms_page_id( $page_id ) {
        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $page_id;
        }
        $localized = self::page_id_from_route( 'terms', $lang );
        return $localized ? $localized : $page_id;
    }

    public static function localized_privacy_url( $url, $policy_page_id = 0 ) {
        $lang = self::current_language();
        if ( 'en' === $lang || empty( self::$routes['privacy'][ $lang ] ) ) {
            return $url;
        }
        return home_url( self::$routes['privacy'][ $lang ] );
    }

    public static function localized_privacy_policy_text( $text, $type ) {
        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $text;
        }
        $url = self::localized_privacy_url( get_privacy_policy_url(), 0 );
        if ( 'ar' === $lang ) {
            $label = 'سياسة الخصوصية';
            $sentence = ( 'checkout' === $type )
                ? 'سيتم استخدام بياناتك الشخصية لمعالجة طلبك، ودعم تجربتك في هذا الموقع، ولأغراض أخرى موضحة في %s.'
                : 'سيتم استخدام بياناتك الشخصية لدعم تجربتك في هذا الموقع، وإدارة الوصول إلى حسابك، ولأغراض أخرى موضحة في %s.';
        } else {
            $label = 'politique de confidentialité';
            $sentence = ( 'checkout' === $type )
                ? 'Vos données personnelles seront utilisées pour traiter votre commande, améliorer votre expérience sur ce site et pour les autres finalités décrites dans notre %s.'
                : 'Vos données personnelles seront utilisées pour faciliter votre expérience sur ce site, gérer l’accès à votre compte et pour les autres finalités décrites dans notre %s.';
        }
        $link = '<a href="' . esc_url( $url ) . '" class="woocommerce-privacy-policy-link" target="_blank">' . esc_html( $label ) . '</a>';
        return '<p>' . sprintf( esc_html( $sentence ), $link ) . '</p>';
    }

    public static function localized_terms_checkbox_text( $text ) {
        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $text;
        }
        $page_id = self::localized_terms_page_id( (int) get_option( 'woocommerce_terms_page_id' ) );
        $url = $page_id ? get_permalink( $page_id ) : '';
        if ( ! $url ) {
            return $text;
        }
        if ( 'ar' === $lang ) {
            return 'لقد قرأت وأوافق على <a href="' . esc_url( $url ) . '" class="woocommerce-terms-and-conditions-link" target="_blank">الشروط والأحكام</a> الخاصة بالموقع';
        }
        return 'J’ai lu et j’accepte les <a href="' . esc_url( $url ) . '" class="woocommerce-terms-and-conditions-link" target="_blank">conditions générales</a> du site';
    }

    public static function localized_gateway_title( $title, $gateway_id ) {
        if ( 'bacs' !== $gateway_id ) {
            return $title;
        }
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            return 'تحويل بنكي (مصر)';
        }
        if ( 'fr' === $lang ) {
            return 'Virement bancaire (Égypte)';
        }
        return 'Bank Transfer (Egypt)';
    }

    public static function localized_gateway_description( $description, $gateway_id ) {
        if ( 'bacs' !== $gateway_id ) {
            return $description;
        }
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            return 'للعملاء في مصر. أرسل الطلب وسنزودك بتعليمات التحويل البنكي. يتم إصدار ترخيص TapBix بعد تأكيد الدفع.';
        }
        if ( 'fr' === $lang ) {
            return 'Pour les clients en Égypte. Passez votre commande et nous vous communiquerons les instructions de virement bancaire. La licence TapBix est délivrée après confirmation du paiement.';
        }
        return 'For customers in Egypt. Place your order and we will provide bank transfer instructions. Your TapBix license is issued after payment is confirmed.';
    }

    public static function localized_add_to_cart_message( $message, $products, $show_qty ) {
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            $message = str_replace( 'has been added to your cart.', 'تمت إضافته إلى سلة مشترياتك.', $message );
            $message = str_replace( 'View cart', 'عرض السلة', $message );
        } elseif ( 'fr' === $lang ) {
            $message = str_replace( 'has been added to your cart.', 'a été ajouté à votre panier.', $message );
            $message = str_replace( 'View cart', 'Voir le panier', $message );
        }
        return $message;
    }

    public static function localize_account_menu( $items ) {
        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $items;
        }

        $labels = array(
            'ar' => array(
                'dashboard' => 'لوحة التحكم',
                'orders' => 'الطلبات',
                'downloads' => 'التحميلات',
                'edit-address' => 'العناوين',
                'edit-account' => 'تفاصيل الحساب',
                'customer-logout' => 'تسجيل الخروج',
                'tapbix-licenses' => 'تراخيص TapBix',
                'licenses' => 'تراخيص TapBix',
            ),
            'fr' => array(
                'dashboard' => 'Tableau de bord',
                'orders' => 'Commandes',
                'downloads' => 'Téléchargements',
                'edit-address' => 'Adresses',
                'edit-account' => 'Détails du compte',
                'customer-logout' => 'Se déconnecter',
                'tapbix-licenses' => 'Licences TapBix',
                'licenses' => 'Licences TapBix',
            ),
        );

        foreach ( $items as $endpoint => $label ) {
            if ( isset( $labels[ $lang ][ $endpoint ] ) ) {
                $items[ $endpoint ] = $labels[ $lang ][ $endpoint ];
                continue;
            }

            $plain = strtolower( trim( wp_strip_all_tags( $label ) ) );
            if ( 'tapbix licenses' === $plain ) {
                $items[ $endpoint ] = ( 'ar' === $lang ) ? 'تراخيص TapBix' : 'Licences TapBix';
            }
        }

        return $items;
    }

    private static function account_translations( $lang ) {
        $ar = array(
            'My account' => 'حسابي',
            'Dashboard' => 'لوحة التحكم',
            'Orders' => 'الطلبات',
            'Downloads' => 'التحميلات',
            'Addresses' => 'العناوين',
            'Address' => 'العنوان',
            'Account details' => 'تفاصيل الحساب',
            'Log out' => 'تسجيل الخروج',
            'Login' => 'تسجيل الدخول',
            'Register' => 'إنشاء حساب',
            'Username or email address' => 'اسم المستخدم أو البريد الإلكتروني',
            'Password' => 'كلمة المرور',
            'Remember me' => 'تذكرني',
            'Lost your password?' => 'نسيت كلمة المرور؟',
            'Email address' => 'البريد الإلكتروني',
            'Username' => 'اسم المستخدم',
            'First name' => 'الاسم الأول',
            'Last name' => 'اسم العائلة',
            'Display name' => 'الاسم الظاهر',
            'Save changes' => 'حفظ التغييرات',
            'Current password (leave blank to leave unchanged)' => 'كلمة المرور الحالية (اتركها فارغة إذا لم ترغب في تغييرها)',
            'New password (leave blank to leave unchanged)' => 'كلمة المرور الجديدة (اتركها فارغة إذا لم ترغب في تغييرها)',
            'Confirm new password' => 'تأكيد كلمة المرور الجديدة',
            'Billing address' => 'عنوان الفوترة',
            'Shipping address' => 'عنوان الشحن',
            'Edit' => 'تعديل',
            'Order' => 'الطلب',
            'Date' => 'التاريخ',
            'Status' => 'الحالة',
            'Total' => 'الإجمالي',
            'Actions' => 'الإجراءات',
            'View' => 'عرض',
            'Download' => 'تحميل',
            'No order has been made yet.' => 'لم يتم إنشاء أي طلب بعد.',
            'Browse products' => 'تصفح المنتجات',
            'No downloads available yet.' => 'لا توجد تحميلات متاحة حتى الآن.',
            'Go shop' => 'اذهب إلى المتجر',
            'Hello %1$s (not %1$s? %2$s)' => 'مرحبًا %1$s (لست %1$s؟ %2$s)',
            'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)' => 'مرحبًا %1$s (لست %1$s؟ <a href="%2$s">تسجيل الخروج</a>)',
            'From your account dashboard you can view your %1$s, manage your %2$s, and %3$s.' => 'من لوحة حسابك يمكنك عرض %1$s، وإدارة %2$s، و%3$s.',
            'From your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">billing address</a>, and <a href="%3$s">edit your password and account details</a>.' => 'من لوحة حسابك يمكنك عرض <a href="%1$s">طلباتك الأخيرة</a>، وإدارة <a href="%2$s">عنوان الفوترة</a>، و<a href="%3$s">تعديل كلمة المرور وتفاصيل الحساب</a>.',
            'From your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">shipping and billing addresses</a>, and <a href="%3$s">edit your password and account details</a>.' => 'من لوحة حسابك يمكنك عرض <a href="%1$s">طلباتك الأخيرة</a>، وإدارة <a href="%2$s">عناوين الشحن والفوترة</a>، و<a href="%3$s">تعديل كلمة المرور وتفاصيل الحساب</a>.',
            'recent orders' => 'طلباتك الأخيرة',
            'billing address' => 'عنوان الفوترة',
            'edit your password and account details' => 'تعديل كلمة المرور وتفاصيل الحساب',
            'The following addresses will be used on the checkout page by default.' => 'سيتم استخدام العناوين التالية افتراضيًا في صفحة إتمام الطلب.',
            'Add' => 'إضافة',
            'Payment methods' => 'طرق الدفع',
            'Account' => 'الحساب',
            'TapBix Licenses' => 'تراخيص TapBix',
            'License' => 'الترخيص',
            'Licenses' => 'التراخيص',
            'Activation code' => 'رمز التفعيل',
            'Devices' => 'الأجهزة',
            'Add another device' => 'إضافة جهاز آخر',
            'Shop' => 'المتجر',
            'Home' => 'الرئيسية',
            'Default sorting' => 'الترتيب الافتراضي',
            'Sort by popularity' => 'الترتيب حسب الأكثر شعبية',
            'Sort by average rating' => 'الترتيب حسب التقييم',
            'Sort by latest' => 'الترتيب حسب الأحدث',
            'Sort by price: low to high' => 'الترتيب حسب السعر: من الأقل إلى الأعلى',
            'Sort by price: high to low' => 'الترتيب حسب السعر: من الأعلى إلى الأقل',
            'Showing the single result' => 'عرض النتيجة المتاحة',
            'Showing all %d results' => 'عرض كل النتائج (%d)',
            'Add to cart' => 'أضف إلى السلة',
            'Read more' => 'اقرأ المزيد',
            'Select options' => 'اختر الخيارات',
            'Software' => 'البرمجيات',
            'Description' => 'الوصف',
            'Reviews' => 'المراجعات',
            'Reviews (%d)' => 'المراجعات (%d)',
            'There are no reviews yet.' => 'لا توجد مراجعات حتى الآن.',
            'Cancel reply' => 'إلغاء الرد',
            'Your email address will not be published.' => 'لن يتم نشر بريدك الإلكتروني.',
            'Required fields are marked %s' => 'الحقول المطلوبة مميزة بعلامة %s',
            'Your rating' => 'تقييمك',
            'Rate…' => 'قيّم…',
            'Perfect' => 'ممتاز',
            'Good' => 'جيد',
            'Average' => 'متوسط',
            'Not that bad' => 'مقبول',
            'Very poor' => 'ضعيف جدًا',
            'Your review' => 'مراجعتك',
            'Name' => 'الاسم',
            'Email' => 'البريد الإلكتروني',
            'Submit' => 'إرسال',
            'Be the first to review “%s”' => 'كن أول من يراجع “%s”',
            'Save my name, email, and website in this browser for the next time I comment.' => 'احفظ اسمي وبريدي الإلكتروني وموقعي في هذا المتصفح لاستخدامها في المرة القادمة.',
            'SKU:' => 'رمز المنتج:',
            'Category:' => 'التصنيف:',
            'Brand:' => 'العلامة التجارية:',
            'Cart' => 'سلة المشتريات',
            'Checkout' => 'إتمام الطلب',
            'Your cart is currently empty.' => 'سلة مشترياتك فارغة حاليًا.',
            'Return to shop' => 'العودة إلى المتجر',
            'View cart' => 'عرض السلة',
            'Remove item' => 'إزالة العنصر',
            'Thumbnail image' => 'صورة مصغرة',
            'Product' => 'المنتج',
            'Price' => 'السعر',
            'Quantity' => 'الكمية',
            'Subtotal' => 'المجموع الفرعي',
            'Coupon:' => 'قسيمة الخصم:',
            'Coupon code' => 'رمز القسيمة',
            'Apply coupon' => 'تطبيق القسيمة',
            'Update cart' => 'تحديث السلة',
            'Cart totals' => 'إجمالي السلة',
            'Proceed to checkout' => 'المتابعة لإتمام الطلب',
            'Returning customer?' => 'هل أنت عميل سابق؟',
            'Click here to login' => 'اضغط هنا لتسجيل الدخول',
            'If you have shopped with us before, please enter your details below. If you are a new customer, please proceed to the Billing section.' => 'إذا سبق لك الشراء منا، أدخل بياناتك أدناه. إذا كنت عميلًا جديدًا، تابع إلى قسم بيانات الفوترة.',
            'Username or email' => 'اسم المستخدم أو البريد الإلكتروني',
            'Required' => 'مطلوب',
            'Have a coupon?' => 'هل لديك قسيمة خصم؟',
            'Click here to enter your code' => 'اضغط هنا لإدخال الرمز',
            'Enter your coupon code' => 'أدخل رمز القسيمة',
            'Billing details' => 'بيانات الفوترة',
            'Company name' => 'اسم الشركة',
            '(optional)' => '(اختياري)',
            'Country / Region' => 'الدولة / المنطقة',
            'Select a country / region…' => 'اختر دولة / منطقة…',
            'Street address' => 'عنوان الشارع',
            'House number and street name' => 'رقم المنزل واسم الشارع',
            'Apartment, suite, unit, etc. (optional)' => 'شقة، جناح، وحدة، إلخ (اختياري)',
            'Town / City' => 'المدينة',
            'State / County' => 'المحافظة / الولاية',
            'Postcode / ZIP' => 'الرمز البريدي',
            'Phone' => 'رقم الهاتف',
            'Additional information' => 'معلومات إضافية',
            'Order notes' => 'ملاحظات الطلب',
            'Order notes (optional)' => 'ملاحظات الطلب (اختياري)',
            'Notes about your order, e.g. special notes for delivery.' => 'ملاحظات حول طلبك، مثل تعليمات خاصة عند الحاجة.',
            'Create an account?' => 'إنشاء حساب؟',
            'Create account password' => 'كلمة مرور الحساب',
            'Ship to a different address?' => 'الشحن إلى عنوان مختلف؟',
            'Your order' => 'طلبك',
            'Payment' => 'الدفع',
            'Payment method' => 'طريقة الدفع',
            'Place order' => 'إرسال الطلب',
            'Update totals' => 'تحديث الإجمالي',
            'Product quantity' => 'كمية المنتج',
            'Thank you. Your order has been received.' => 'شكرًا لك. تم استلام طلبك.',
            'Order number:' => 'رقم الطلب:',
            'Date:' => 'التاريخ:',
            'Email:' => 'البريد الإلكتروني:',
            'Total:' => 'الإجمالي:',
            'Payment method:' => 'طريقة الدفع:',
        );

        $fr = array(
            'My account' => 'Mon compte',
            'Dashboard' => 'Tableau de bord',
            'Orders' => 'Commandes',
            'Downloads' => 'Téléchargements',
            'Addresses' => 'Adresses',
            'Address' => 'Adresse',
            'Account details' => 'Détails du compte',
            'Log out' => 'Se déconnecter',
            'Login' => 'Connexion',
            'Register' => 'Créer un compte',
            'Username or email address' => 'Nom d’utilisateur ou adresse e-mail',
            'Password' => 'Mot de passe',
            'Remember me' => 'Se souvenir de moi',
            'Lost your password?' => 'Mot de passe oublié ?',
            'Email address' => 'Adresse e-mail',
            'Username' => 'Nom d’utilisateur',
            'First name' => 'Prénom',
            'Last name' => 'Nom',
            'Display name' => 'Nom affiché',
            'Save changes' => 'Enregistrer les modifications',
            'Current password (leave blank to leave unchanged)' => 'Mot de passe actuel (laisser vide pour ne pas le modifier)',
            'New password (leave blank to leave unchanged)' => 'Nouveau mot de passe (laisser vide pour ne pas le modifier)',
            'Confirm new password' => 'Confirmer le nouveau mot de passe',
            'Billing address' => 'Adresse de facturation',
            'Shipping address' => 'Adresse de livraison',
            'Edit' => 'Modifier',
            'Order' => 'Commande',
            'Date' => 'Date',
            'Status' => 'Statut',
            'Total' => 'Total',
            'Actions' => 'Actions',
            'View' => 'Voir',
            'Download' => 'Télécharger',
            'No order has been made yet.' => 'Aucune commande n’a encore été passée.',
            'Browse products' => 'Parcourir les produits',
            'No downloads available yet.' => 'Aucun téléchargement disponible pour le moment.',
            'Go shop' => 'Voir la boutique',
            'Hello %1$s (not %1$s? %2$s)' => 'Bonjour %1$s (ce n’est pas %1$s ? %2$s)',
            'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)' => 'Bonjour %1$s (ce n’est pas %1$s ? <a href="%2$s">Se déconnecter</a>)',
            'From your account dashboard you can view your %1$s, manage your %2$s, and %3$s.' => 'Depuis votre tableau de bord, vous pouvez consulter vos %1$s, gérer votre %2$s et %3$s.',
            'From your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">billing address</a>, and <a href="%3$s">edit your password and account details</a>.' => 'Depuis votre tableau de bord, vous pouvez consulter vos <a href="%1$s">commandes récentes</a>, gérer votre <a href="%2$s">adresse de facturation</a> et <a href="%3$s">modifier votre mot de passe et les détails de votre compte</a>.',
            'From your account dashboard you can view your <a href="%1$s">recent orders</a>, manage your <a href="%2$s">shipping and billing addresses</a>, and <a href="%3$s">edit your password and account details</a>.' => 'Depuis votre tableau de bord, vous pouvez consulter vos <a href="%1$s">commandes récentes</a>, gérer vos <a href="%2$s">adresses de livraison et de facturation</a> et <a href="%3$s">modifier votre mot de passe et les détails de votre compte</a>.',
            'recent orders' => 'commandes récentes',
            'billing address' => 'adresse de facturation',
            'edit your password and account details' => 'modifier votre mot de passe et les détails de votre compte',
            'The following addresses will be used on the checkout page by default.' => 'Les adresses suivantes seront utilisées par défaut lors du paiement.',
            'Add' => 'Ajouter',
            'Payment methods' => 'Moyens de paiement',
            'Account' => 'Compte',
            'TapBix Licenses' => 'Licences TapBix',
            'License' => 'Licence',
            'Licenses' => 'Licences',
            'Activation code' => 'Code d’activation',
            'Devices' => 'Appareils',
            'Add another device' => 'Ajouter un autre appareil',
            'Shop' => 'Boutique',
            'Home' => 'Accueil',
            'Default sorting' => 'Tri par défaut',
            'Sort by popularity' => 'Trier par popularité',
            'Sort by average rating' => 'Trier par note moyenne',
            'Sort by latest' => 'Trier par nouveautés',
            'Sort by price: low to high' => 'Trier par prix croissant',
            'Sort by price: high to low' => 'Trier par prix décroissant',
            'Showing the single result' => 'Affichage du seul résultat',
            'Showing all %d results' => 'Affichage des %d résultats',
            'Add to cart' => 'Ajouter au panier',
            'Read more' => 'En savoir plus',
            'Select options' => 'Choisir les options',
            'Software' => 'Logiciels',
            'Description' => 'Description',
            'Reviews' => 'Avis',
            'Reviews (%d)' => 'Avis (%d)',
            'There are no reviews yet.' => 'Il n’y a pas encore d’avis.',
            'Cancel reply' => 'Annuler la réponse',
            'Your email address will not be published.' => 'Votre adresse e-mail ne sera pas publiée.',
            'Required fields are marked %s' => 'Les champs obligatoires sont indiqués par %s',
            'Your rating' => 'Votre note',
            'Rate…' => 'Noter…',
            'Perfect' => 'Parfait',
            'Good' => 'Bien',
            'Average' => 'Moyen',
            'Not that bad' => 'Passable',
            'Very poor' => 'Très mauvais',
            'Your review' => 'Votre avis',
            'Name' => 'Nom',
            'Email' => 'E-mail',
            'Submit' => 'Envoyer',
            'Be the first to review “%s”' => 'Soyez le premier à laisser un avis sur « %s »',
            'Save my name, email, and website in this browser for the next time I comment.' => 'Enregistrer mon nom, mon e-mail et mon site dans ce navigateur pour mon prochain commentaire.',
            'SKU:' => 'UGS :',
            'Category:' => 'Catégorie :',
            'Brand:' => 'Marque :',
            'Cart' => 'Panier',
            'Checkout' => 'Paiement',
            'Your cart is currently empty.' => 'Votre panier est actuellement vide.',
            'Return to shop' => 'Retour à la boutique',
            'View cart' => 'Voir le panier',
            'Remove item' => 'Retirer l’article',
            'Thumbnail image' => 'Image miniature',
            'Product' => 'Produit',
            'Price' => 'Prix',
            'Quantity' => 'Quantité',
            'Subtotal' => 'Sous-total',
            'Coupon:' => 'Code promo :',
            'Coupon code' => 'Code promo',
            'Apply coupon' => 'Appliquer le code promo',
            'Update cart' => 'Mettre à jour le panier',
            'Cart totals' => 'Total du panier',
            'Proceed to checkout' => 'Passer au paiement',
            'Returning customer?' => 'Déjà client ?',
            'Click here to login' => 'Cliquez ici pour vous connecter',
            'If you have shopped with us before, please enter your details below. If you are a new customer, please proceed to the Billing section.' => 'Si vous avez déjà commandé chez nous, saisissez vos informations ci-dessous. Si vous êtes un nouveau client, poursuivez vers la section de facturation.',
            'Username or email' => 'Nom d’utilisateur ou e-mail',
            'Required' => 'Obligatoire',
            'Have a coupon?' => 'Vous avez un code promo ?',
            'Click here to enter your code' => 'Cliquez ici pour saisir votre code',
            'Enter your coupon code' => 'Saisissez votre code promo',
            'Billing details' => 'Détails de facturation',
            'Company name' => 'Nom de l’entreprise',
            '(optional)' => '(facultatif)',
            'Country / Region' => 'Pays / Région',
            'Select a country / region…' => 'Sélectionnez un pays / une région…',
            'Street address' => 'Adresse',
            'House number and street name' => 'Numéro et nom de rue',
            'Apartment, suite, unit, etc. (optional)' => 'Appartement, suite, unité, etc. (facultatif)',
            'Town / City' => 'Ville',
            'State / County' => 'État / Région',
            'Postcode / ZIP' => 'Code postal',
            'Phone' => 'Téléphone',
            'Additional information' => 'Informations complémentaires',
            'Order notes' => 'Notes de commande',
            'Order notes (optional)' => 'Notes de commande (facultatif)',
            'Notes about your order, e.g. special notes for delivery.' => 'Notes concernant votre commande, par exemple des instructions particulières.',
            'Create an account?' => 'Créer un compte ?',
            'Create account password' => 'Mot de passe du compte',
            'Ship to a different address?' => 'Livrer à une adresse différente ?',
            'Your order' => 'Votre commande',
            'Payment' => 'Paiement',
            'Payment method' => 'Moyen de paiement',
            'Place order' => 'Passer la commande',
            'Update totals' => 'Mettre à jour les totaux',
            'Product quantity' => 'Quantité du produit',
            'Thank you. Your order has been received.' => 'Merci. Votre commande a bien été reçue.',
            'Order number:' => 'Numéro de commande :',
            'Date:' => 'Date :',
            'Email:' => 'E-mail :',
            'Total:' => 'Total :',
            'Payment method:' => 'Moyen de paiement :',
        );

        return ( 'ar' === $lang ) ? $ar : ( ( 'fr' === $lang ) ? $fr : array() );
    }

    public static function localize_gettext( $translated, $text, $domain ) {
        if ( is_admin() && ! wp_doing_ajax() ) {
            return $translated;
        }

        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $translated;
        }

        $map = self::account_translations( $lang );
        if ( isset( $map[ $text ] ) ) {
            return $map[ $text ];
        }

        // Some custom account extensions do not use the WooCommerce text domain.
        if ( isset( $map[ $translated ] ) ) {
            return $map[ $translated ];
        }

        // WooCommerce dashboard strings include HTML in current versions. Keep a
        // pattern fallback so minor template wording changes do not leak English.
        if ( false !== strpos( $text, 'Hello %1$s' ) && false !== strpos( $text, 'Log out' ) ) {
            return ( 'ar' === $lang )
                ? 'مرحبًا %1$s (لست %1$s؟ <a href="%2$s">تسجيل الخروج</a>)'
                : 'Bonjour %1$s (ce n’est pas %1$s ? <a href="%2$s">Se déconnecter</a>)';
        }
        if ( 0 === strpos( $text, 'From your account dashboard you can view your ' ) ) {
            if ( false !== strpos( $text, 'shipping and billing addresses' ) ) {
                return ( 'ar' === $lang )
                    ? 'من لوحة حسابك يمكنك عرض <a href="%1$s">طلباتك الأخيرة</a>، وإدارة <a href="%2$s">عناوين الشحن والفوترة</a>، و<a href="%3$s">تعديل كلمة المرور وتفاصيل الحساب</a>.'
                    : 'Depuis votre tableau de bord, vous pouvez consulter vos <a href="%1$s">commandes récentes</a>, gérer vos <a href="%2$s">adresses de livraison et de facturation</a> et <a href="%3$s">modifier votre mot de passe et les détails de votre compte</a>.';
            }
            return ( 'ar' === $lang )
                ? 'من لوحة حسابك يمكنك عرض <a href="%1$s">طلباتك الأخيرة</a>، وإدارة <a href="%2$s">عنوان الفوترة</a>، و<a href="%3$s">تعديل كلمة المرور وتفاصيل الحساب</a>.'
                : 'Depuis votre tableau de bord, vous pouvez consulter vos <a href="%1$s">commandes récentes</a>, gérer votre <a href="%2$s">adresse de facturation</a> et <a href="%3$s">modifier votre mot de passe et les détails de votre compte</a>.';
        }

        return $translated;
    }

    public static function localize_ngettext( $translation, $single, $plural, $number, $domain ) {
        if ( is_admin() && ! wp_doing_ajax() ) {
            return $translation;
        }

        $lang = self::current_language();
        if ( 'en' === $lang ) {
            return $translation;
        }
        $map = self::account_translations( $lang );
        if ( 'Showing the single result' === $single && 1 === (int) $number ) {
            return ( 'ar' === $lang ) ? 'عرض النتيجة المتاحة' : 'Affichage du seul résultat';
        }
        if ( false !== strpos( $plural, 'Showing all %d results' ) ) {
            return ( 'ar' === $lang ) ? 'عرض كل النتائج (%d)' : 'Affichage des %d résultats';
        }
        if ( 1 === (int) $number && isset( $map[ $single ] ) ) {
            return $map[ $single ];
        }
        if ( isset( $map[ $plural ] ) ) {
            return $map[ $plural ];
        }
        return $translation;
    }

    public static function account_intro_shortcode() {
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            $title = 'حسابي';
            $text  = 'أدر طلباتك وتحميلاتك وتفاصيل حسابك وتراخيص TapBix من مكان واحد.';
        } elseif ( 'fr' === $lang ) {
            $title = 'Mon compte';
            $text  = 'Gérez vos commandes, téléchargements, informations de compte et licences TapBix depuis un seul endroit.';
        } else {
            $title = 'My account';
            $text  = 'Manage your orders, downloads, account details and TapBix licenses from one place.';
        }

        return '<div class="tapix-account-intro"><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $text ) . '</p></div>';
    }

    public static function cart_intro_shortcode() {
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            $title = 'سلة المشتريات';
            $text  = 'راجع المنتجات الموجودة في سلتك قبل الانتقال إلى إتمام الطلب.';
        } elseif ( 'fr' === $lang ) {
            $title = 'Panier';
            $text  = 'Vérifiez les articles de votre panier avant de passer au paiement.';
        } else {
            $title = 'Cart';
            $text  = 'Review the items in your cart before continuing to checkout.';
        }
        return '<div class="tapix-commerce-intro"><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $text ) . '</p></div>';
    }

    public static function checkout_intro_shortcode() {
        $lang = self::current_language();
        if ( 'ar' === $lang ) {
            $title = 'إتمام الطلب';
            $text  = 'أدخل بياناتك وراجع طلبك وطريقة الدفع قبل التأكيد.';
        } elseif ( 'fr' === $lang ) {
            $title = 'Paiement';
            $text  = 'Saisissez vos informations, vérifiez votre commande et votre moyen de paiement avant de confirmer.';
        } else {
            $title = 'Checkout';
            $text  = 'Enter your details, review your order and payment method, then confirm your purchase.';
        }
        return '<div class="tapix-commerce-intro"><h1>' . esc_html( $title ) . '</h1><p>' . esc_html( $text ) . '</p></div>';
    }

    public static function commerce_styles() {
        if ( ! function_exists( 'is_cart' ) || ( ! is_cart() && ! is_checkout() ) ) {
            return;
        }
        ?>
        <style id="tapix-commerce-i18n-css">
            .tapix-commerce-intro{margin:0 0 28px}.tapix-commerce-intro h1{margin:0 0 8px;color:#0f172a;font-size:38px;line-height:1.25}.tapix-commerce-intro p{margin:0;color:#475569;font-size:16px}
            .woocommerce-cart-form,.cart_totals,.woocommerce-checkout #customer_details,.woocommerce-checkout-review-order{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:22px}
            .woocommerce table.shop_table{border-color:#e2e8f0}.woocommerce form .form-row input.input-text,.woocommerce form .form-row textarea,.woocommerce form .form-row select{border-radius:8px}
            body.tapix-lang-ar.woocommerce-cart .woocommerce,body.tapix-lang-ar.woocommerce-checkout .woocommerce{direction:rtl;text-align:right}
            body.tapix-lang-ar .woocommerce form .form-row label,body.tapix-lang-ar .woocommerce table.shop_table th,body.tapix-lang-ar .woocommerce table.shop_table td{text-align:right}
            body.tapix-lang-ar .select2-container .select2-selection--single{text-align:right}
            @media(max-width:767px){.tapix-commerce-intro h1{font-size:32px}.woocommerce-cart-form,.cart_totals,.woocommerce-checkout #customer_details,.woocommerce-checkout-review-order{padding:16px}}
        </style>
        <?php
    }

    public static function account_styles() {
        if ( ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
            return;
        }
        $lang = self::current_language();
        ?>
        <style id="tapix-account-i18n-css">
            .tapix-account-intro{margin:0 0 28px}.tapix-account-intro h1{margin:0 0 8px;color:#0f172a;font-size:38px;line-height:1.25}.tapix-account-intro p{margin:0;color:#475569;font-size:16px}
            .woocommerce-MyAccount-navigation ul{border:1px solid #e2e8f0;border-radius:14px;overflow:hidden;background:#fff}
            .woocommerce-MyAccount-navigation ul li{border-bottom:1px solid #e2e8f0}.woocommerce-MyAccount-navigation ul li:last-child{border-bottom:0}
            .woocommerce-MyAccount-navigation ul li a{display:block;padding:13px 16px;text-decoration:none}.woocommerce-MyAccount-navigation ul li.is-active a{font-weight:700;background:#f8fafc;color:#0f172a}
            .woocommerce-MyAccount-content{background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:28px;min-height:260px}
            body.tapix-lang-ar .woocommerce-account, body.tapix-lang-ar .woocommerce-MyAccount-content, body.tapix-lang-ar .woocommerce-MyAccount-navigation, body.tapix-lang-ar .tapix-account-intro{direction:rtl;text-align:right}
            body.tapix-lang-ar .woocommerce-MyAccount-navigation{float:right} body.tapix-lang-ar .woocommerce-MyAccount-content{float:left}
            @media(max-width:767px){.tapix-account-intro h1{font-size:32px}.woocommerce-MyAccount-navigation,.woocommerce-MyAccount-content{float:none!important;width:100%!important}.woocommerce-MyAccount-content{margin-top:20px;padding:20px}}
        </style>
        <?php
    }

    public static function switcher_script() {
        if ( is_admin() ) {
            return;
        }
        ?>
        <script id="tapix-language-router-js">
        (function(){
            var currentLang = '<?php echo esc_js( self::current_language() ); ?>';
            var localizedHome = '<?php echo esc_url( home_url( self::$routes['home'][ self::current_language() ] ) ); ?>';
            function setLang(lang){
                document.cookie = '<?php echo esc_js( self::COOKIE ); ?>=' + lang + '; path=/; max-age=31536000; SameSite=Lax';
            }
            document.querySelectorAll('.site-title a').forEach(function(a){ a.setAttribute('href', localizedHome); });
            document.querySelectorAll('.ast-footer-copyright p').forEach(function(p){
                var year = new Date().getFullYear();
                if(currentLang === 'ar'){ p.textContent = '© ' + year + ' Tapix Solutions. جميع الحقوق محفوظة.'; }
                else if(currentLang === 'fr'){ p.textContent = '© ' + year + ' Tapix Solutions. Tous droits réservés.'; }
                else { p.textContent = '© ' + year + ' Tapix Solutions. All rights reserved.'; }
            });
            document.addEventListener('click', function(e){
                var a = e.target.closest('.elementor-element-langbar1 a');
                if(!a){ return; }
                var href = a.getAttribute('href') || '';
                if(href.indexOf('/ar/') !== -1){ setLang('ar'); }
                else if(href.indexOf('/fr/') !== -1){ setLang('fr'); }
                else { setLang('en'); }
            }, true);
        })();
        </script>
        <?php
    }
}

Tapix_Language_Router::boot();
