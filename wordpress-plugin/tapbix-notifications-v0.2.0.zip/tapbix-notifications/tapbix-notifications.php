<?php
/**
 * Plugin Name: TapBix Notifications
 * Description: Standalone push-notification control center for TapBix. Independent from licensing, subscriptions, WooCommerce, and RevenueCat.
 * Version: 0.2.0
 * Author: Tapix Solutions
 * Requires at least: 6.5
 * Requires PHP: 8.0
 */

if (!defined('ABSPATH')) {
    exit;
}

final class TapBix_Notifications_Plugin {
    private const VERSION = '0.2.0';
    private const DB_VERSION = '2';
    private const REST_NAMESPACE = 'tapbix-push/v1';
    private const OPTION_SERVICE_ACCOUNT = 'tapbix_push_service_account_v1';
    private const OPTION_DB_VERSION = 'tapbix_push_db_version_v2';
    private const EXPECTED_FIREBASE_PROJECT = 'tapix-1d5fa';
    private const ACCESS_TOKEN_SCOPE = 'https://www.googleapis.com/auth/firebase.messaging';
    private const QUEUE_HOOK = 'tapbix_push_process_queue';
    private const SINGLE_HOOK = 'tapbix_push_run_notification';

    public static function init(): void {
        add_action('plugins_loaded', [self::class, 'maybe_upgrade']);
        add_action('rest_api_init', [self::class, 'register_rest_routes']);
        add_action('admin_menu', [self::class, 'register_admin_menu']);
        add_action('admin_post_tapbix_push_send', [self::class, 'handle_send']);
        add_action('admin_post_tapbix_push_cancel', [self::class, 'handle_cancel']);
        add_action('admin_post_tapbix_push_save_settings', [self::class, 'handle_save_settings']);
        add_filter('cron_schedules', [self::class, 'cron_schedules']);
        add_action('init', [self::class, 'ensure_queue_cron']);
        add_action(self::QUEUE_HOOK, [self::class, 'process_queue']);
        add_action(self::SINGLE_HOOK, [self::class, 'run_scheduled_notification'], 10, 1);
    }

    public static function activate(): void {
        self::install_schema();
        self::ensure_queue_cron();
    }

    public static function deactivate(): void {
        wp_clear_scheduled_hook(self::QUEUE_HOOK);
    }

    public static function cron_schedules(array $schedules): array {
        if (!isset($schedules['tapbix_five_minutes'])) {
            $schedules['tapbix_five_minutes'] = [
                'interval' => 5 * MINUTE_IN_SECONDS,
                'display' => 'Every 5 minutes (TapBix Notifications)',
            ];
        }
        return $schedules;
    }

    public static function ensure_queue_cron(): void {
        if (!wp_next_scheduled(self::QUEUE_HOOK)) {
            wp_schedule_event(time() + 60, 'tapbix_five_minutes', self::QUEUE_HOOK);
        }
    }

    public static function maybe_upgrade(): void {
        if ((string) get_option(self::OPTION_DB_VERSION, '') !== self::DB_VERSION) {
            self::install_schema();
        }
    }

    private static function install_schema(): void {
        global $wpdb;
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        $charset_collate = $wpdb->get_charset_collate();

        $devices = self::devices_table();
        $sql_devices = "CREATE TABLE {$devices} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            token_hash char(64) NOT NULL,
            fcm_token text NOT NULL,
            install_id varchar(100) NOT NULL DEFAULT '',
            platform varchar(20) NOT NULL,
            locale varchar(12) NOT NULL DEFAULT '',
            app_version varchar(50) NOT NULL DEFAULT '',
            device_name varchar(191) NOT NULL DEFAULT '',
            notifications_enabled tinyint(1) NOT NULL DEFAULT 1,
            last_seen datetime NOT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY token_hash (token_hash),
            KEY install_platform (install_id, platform),
            KEY platform (platform),
            KEY locale (locale),
            KEY last_seen (last_seen)
        ) {$charset_collate};";
        dbDelta($sql_devices);

        $notifications = self::notifications_table();
        $sql_notifications = "CREATE TABLE {$notifications} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            title varchar(100) NOT NULL,
            body text NOT NULL,
            audience varchar(20) NOT NULL DEFAULT 'all',
            locale varchar(12) NOT NULL DEFAULT '',
            device_id bigint(20) unsigned NULL,
            validate_only tinyint(1) NOT NULL DEFAULT 0,
            status varchar(20) NOT NULL DEFAULT 'pending',
            scheduled_at datetime NULL,
            sent_at datetime NULL,
            target_count int unsigned NOT NULL DEFAULT 0,
            accepted_count int unsigned NOT NULL DEFAULT 0,
            failed_count int unsigned NOT NULL DEFAULT 0,
            firebase_name varchar(255) NOT NULL DEFAULT '',
            last_error text NULL,
            created_by bigint(20) unsigned NOT NULL DEFAULT 0,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY  (id),
            KEY status_scheduled (status, scheduled_at),
            KEY created_at (created_at)
        ) {$charset_collate};";
        dbDelta($sql_notifications);

        update_option(self::OPTION_DB_VERSION, self::DB_VERSION, false);
    }

    private static function devices_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'tapbix_push_devices';
    }

    private static function notifications_table(): string {
        global $wpdb;
        return $wpdb->prefix . 'tapbix_push_notifications';
    }

    public static function register_rest_routes(): void {
        register_rest_route(self::REST_NAMESPACE, '/register', [
            'methods' => WP_REST_Server::CREATABLE,
            'callback' => [self::class, 'rest_register_device'],
            'permission_callback' => '__return_true',
        ]);

        register_rest_route(self::REST_NAMESPACE, '/health', [
            'methods' => WP_REST_Server::READABLE,
            'callback' => static function (): WP_REST_Response {
                return new WP_REST_Response([
                    'ok' => true,
                    'service' => 'tapbix-notifications',
                    'version' => self::VERSION,
                ]);
            },
            'permission_callback' => '__return_true',
        ]);
    }

    public static function rest_register_device(WP_REST_Request $request) {
        $rate_limited = self::rate_limit_registration();
        if (is_wp_error($rate_limited)) {
            return $rate_limited;
        }

        $payload = $request->get_json_params();
        if (!is_array($payload)) {
            return new WP_Error('tapbix_push_invalid_json', 'Invalid JSON body.', ['status' => 400]);
        }

        $token = trim((string) ($payload['token'] ?? ''));
        if (strlen($token) < 50 || strlen($token) > 4096) {
            return new WP_Error('tapbix_push_invalid_token', 'Invalid push token.', ['status' => 400]);
        }

        $platform = strtolower(sanitize_key((string) ($payload['platform'] ?? '')));
        if (!in_array($platform, ['android', 'ios', 'windows'], true)) {
            return new WP_Error('tapbix_push_invalid_platform', 'Unsupported platform.', ['status' => 400]);
        }

        $install_id = substr(sanitize_text_field((string) ($payload['install_id'] ?? '')), 0, 100);
        $locale = self::normalize_locale((string) ($payload['locale'] ?? ''));
        $app_version = substr(sanitize_text_field((string) ($payload['app_version'] ?? '')), 0, 50);
        $device_name = substr(sanitize_text_field((string) ($payload['device_name'] ?? '')), 0, 191);
        $enabled = !isset($payload['notifications_enabled']) || (bool) $payload['notifications_enabled'];

        global $wpdb;
        $table = self::devices_table();
        $token_hash = hash('sha256', $token);
        $now = current_time('mysql', true);

        $existing_id = (int) $wpdb->get_var(
            $wpdb->prepare("SELECT id FROM {$table} WHERE token_hash = %s LIMIT 1", $token_hash)
        );
        if (!$existing_id && $install_id !== '') {
            $existing_id = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$table} WHERE install_id = %s AND platform = %s ORDER BY updated_at DESC LIMIT 1",
                    $install_id,
                    $platform
                )
            );
        }

        $data = [
            'token_hash' => $token_hash,
            'fcm_token' => $token,
            'install_id' => $install_id,
            'platform' => $platform,
            'locale' => $locale,
            'app_version' => $app_version,
            'device_name' => $device_name,
            'notifications_enabled' => $enabled ? 1 : 0,
            'last_seen' => $now,
            'updated_at' => $now,
        ];

        if ($existing_id) {
            $result = $wpdb->update(
                $table,
                $data,
                ['id' => $existing_id],
                ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s'],
                ['%d']
            );
            $device_id = $existing_id;
        } else {
            $data['created_at'] = $now;
            $result = $wpdb->insert(
                $table,
                $data,
                ['%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s']
            );
            $device_id = (int) $wpdb->insert_id;
        }

        if ($result === false) {
            return new WP_Error('tapbix_push_db_error', 'Unable to register this device.', ['status' => 500]);
        }

        return new WP_REST_Response([
            'ok' => true,
            'device_id' => $device_id,
            'registered_at' => $now,
        ], 200);
    }

    private static function normalize_locale(string $locale): string {
        $locale = strtolower(substr(sanitize_key($locale), 0, 2));
        return in_array($locale, ['ar', 'en', 'fr'], true) ? $locale : 'en';
    }

    private static function rate_limit_registration() {
        $ip = isset($_SERVER['REMOTE_ADDR']) ? sanitize_text_field(wp_unslash($_SERVER['REMOTE_ADDR'])) : 'unknown';
        $key = 'tapbix_push_rl_' . md5($ip);
        $count = (int) get_transient($key);
        if ($count >= 120) {
            return new WP_Error('tapbix_push_rate_limited', 'Too many registration attempts. Try again later.', ['status' => 429]);
        }
        set_transient($key, $count + 1, 10 * MINUTE_IN_SECONDS);
        return true;
    }

    public static function register_admin_menu(): void {
        add_menu_page(
            'TapBix Notifications',
            'TapBix Notifications',
            'manage_options',
            'tapbix-notifications',
            [self::class, 'render_admin_page'],
            'dashicons-megaphone',
            58
        );
    }

    public static function render_admin_page(): void {
        if (!current_user_can('manage_options')) return;

        $tab = isset($_GET['tab']) ? sanitize_key(wp_unslash($_GET['tab'])) : 'send';
        if (!in_array($tab, ['send', 'devices', 'history', 'settings'], true)) $tab = 'send';

        $notice = get_transient('tapbix_push_notice_' . get_current_user_id());
        if ($notice) delete_transient('tapbix_push_notice_' . get_current_user_id());

        echo '<div class="wrap">';
        echo '<h1>TapBix Notifications</h1>';
        echo '<p>Standalone push messaging. This plugin does <strong>not</strong> read or modify TapBix licenses, subscriptions, WooCommerce orders, or RevenueCat data.</p>';

        if (is_array($notice) && !empty($notice['message'])) {
            $class = !empty($notice['success']) ? 'notice notice-success' : 'notice notice-error';
            echo '<div class="' . esc_attr($class) . ' is-dismissible"><p>' . esc_html($notice['message']) . '</p></div>';
        }

        $base = admin_url('admin.php?page=tapbix-notifications');
        echo '<nav class="nav-tab-wrapper">';
        foreach (['send' => 'Send', 'devices' => 'Devices', 'history' => 'History & Schedule', 'settings' => 'Firebase Settings'] as $slug => $label) {
            $url = add_query_arg('tab', $slug, $base);
            $active = $tab === $slug ? ' nav-tab-active' : '';
            echo '<a class="nav-tab' . esc_attr($active) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
        }
        echo '</nav><div style="max-width:1100px;margin-top:22px">';

        if ($tab === 'settings') self::render_settings_tab();
        elseif ($tab === 'devices') self::render_devices_tab();
        elseif ($tab === 'history') self::render_history_tab();
        else self::render_send_tab();

        echo '</div></div>';
    }

    private static function render_send_tab(): void {
        global $wpdb;
        $table = self::devices_table();
        $total = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE notifications_enabled = 1");
        $android = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE notifications_enabled = 1 AND platform = 'android'");
        $ios = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table} WHERE notifications_enabled = 1 AND platform = 'ios'");
        $scheduled = (int) $wpdb->get_var("SELECT COUNT(*) FROM " . self::notifications_table() . " WHERE status = 'scheduled'");
        $configured = self::get_service_account() !== null;

        echo '<div style="display:flex;gap:14px;flex-wrap:wrap;margin-bottom:22px">';
        self::stat_card('Registered', $total);
        self::stat_card('Android', $android);
        self::stat_card('iPhone / iPad', $ios);
        self::stat_card('Scheduled', $scheduled);
        echo '</div>';

        if (!$configured) {
            $settings_url = add_query_arg(['page' => 'tapbix-notifications', 'tab' => 'settings'], admin_url('admin.php'));
            echo '<div class="notice notice-warning inline"><p>Firebase sending credentials are not configured. <a href="' . esc_url($settings_url) . '">Configure Firebase</a>.</p></div>';
        }

        $devices = $wpdb->get_results("SELECT id, platform, locale, app_version, device_name FROM {$table} WHERE notifications_enabled = 1 ORDER BY last_seen DESC LIMIT 300", ARRAY_A);
        $preselected = isset($_GET['device_id']) ? absint($_GET['device_id']) : 0;

        echo '<div class="card" style="max-width:820px;padding:22px">';
        echo '<h2 style="margin-top:0">Create notification</h2>';
        echo '<form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('tapbix_push_send');
        echo '<input type="hidden" name="action" value="tapbix_push_send">';
        echo '<table class="form-table" role="presentation">';
        echo '<tr><th><label for="tbx-title">Title</label></th><td><input class="regular-text" id="tbx-title" name="title" maxlength="100" required placeholder="TapBix update"></td></tr>';
        echo '<tr><th><label for="tbx-body">Message</label></th><td><textarea class="large-text" rows="5" id="tbx-body" name="body" maxlength="500" required placeholder="Write the message users will receive..."></textarea></td></tr>';
        echo '<tr><th><label for="tbx-audience">Audience</label></th><td><select id="tbx-audience" name="audience">';
        foreach (['all' => 'All mobile devices', 'android' => 'Android only', 'ios' => 'iPhone / iPad only', 'device' => 'One specific device'] as $value => $label) {
            $selected = ($preselected && $value === 'device') ? ' selected' : '';
            echo '<option value="' . esc_attr($value) . '"' . $selected . '>' . esc_html($label) . '</option>';
        }
        echo '</select></td></tr>';
        echo '<tr id="tbx-device-row"' . ($preselected ? '' : ' style="display:none"') . '><th><label for="tbx-device">Device</label></th><td><select id="tbx-device" name="device_id" style="min-width:420px"><option value="0">Choose a device…</option>';
        foreach ($devices as $device) {
            $id = (int) $device['id'];
            $label = '#' . $id . ' · ' . $device['device_name'] . ' · ' . strtoupper((string) $device['platform']) . ' · ' . (string) $device['app_version'] . ' · ' . strtoupper((string) $device['locale']);
            echo '<option value="' . esc_attr((string) $id) . '"' . selected($preselected, $id, false) . '>' . esc_html($label) . '</option>';
        }
        echo '</select></td></tr>';
        echo '<tr id="tbx-language-row"><th><label for="tbx-locale">Language</label></th><td><select id="tbx-locale" name="locale"><option value="">All languages</option><option value="ar">Arabic</option><option value="en">English</option><option value="fr">French</option></select><p class="description">Language targeting uses the language selected inside TapBix.</p></td></tr>';
        echo '<tr><th>Delivery</th><td><label style="margin-right:18px"><input type="radio" name="delivery" value="now" checked> Send now</label><label><input type="radio" name="delivery" value="schedule"> Schedule</label><div id="tbx-schedule-box" style="display:none;margin-top:10px"><input type="datetime-local" name="schedule_at"><p class="description">Uses the WordPress site timezone: ' . esc_html(wp_timezone_string()) . '. WordPress scheduled jobs may run a few minutes late on a low-traffic site.</p></div></td></tr>';
        echo '<tr><th>Safe test</th><td><label><input type="checkbox" name="validate_only" value="1"> Validate with Firebase only; do not deliver</label><p class="description">Validation always runs immediately and is not scheduled.</p></td></tr>';
        echo '</table>';
        submit_button('Send / Schedule Notification', 'primary', 'submit', false, $configured ? [] : ['disabled' => 'disabled']);
        echo '</form></div>';

        echo '<script>(function(){const a=document.getElementById("tbx-audience"),d=document.getElementById("tbx-device-row"),l=document.getElementById("tbx-language-row");function syncAudience(){const one=a.value==="device";d.style.display=one?"table-row":"none";l.style.display=one?"none":"table-row";}a.addEventListener("change",syncAudience);syncAudience();document.querySelectorAll("input[name=delivery]").forEach(function(r){r.addEventListener("change",function(){document.getElementById("tbx-schedule-box").style.display=this.value==="schedule"&&this.checked?"block":"none";});});})();</script>';
    }

    private static function stat_card(string $label, int $value): void {
        echo '<div class="card" style="min-width:170px;padding:16px 20px;margin:0"><div style="font-size:28px;font-weight:700">' . esc_html((string) $value) . '</div><div>' . esc_html($label) . '</div></div>';
    }

    private static function render_devices_tab(): void {
        global $wpdb;
        $table = self::devices_table();
        $rows = $wpdb->get_results("SELECT id, platform, locale, app_version, device_name, fcm_token, notifications_enabled, last_seen FROM {$table} ORDER BY last_seen DESC LIMIT 300", ARRAY_A);
        echo '<h2>Registered notification devices</h2><p>These records belong only to TapBix Notifications. There is no license key, order ID, subscription ID, or licensing-table link.</p>';
        if (!$rows) { echo '<p>No devices have registered yet.</p>'; return; }

        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Platform</th><th>Device</th><th>App</th><th>Language</th><th>Status</th><th>Token</th><th>Last seen (UTC)</th><th></th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $token = (string) $row['fcm_token'];
            $masked = strlen($token) > 18 ? substr($token, 0, 8) . '…' . substr($token, -8) : 'hidden';
            $send_url = add_query_arg(['page' => 'tapbix-notifications', 'tab' => 'send', 'device_id' => (int) $row['id']], admin_url('admin.php'));
            echo '<tr><td>#' . esc_html((string) $row['id']) . '</td><td>' . esc_html((string) $row['platform']) . '</td><td>' . esc_html((string) $row['device_name']) . '</td><td>' . esc_html((string) $row['app_version']) . '</td><td>' . esc_html(strtoupper((string) $row['locale'])) . '</td><td>' . ((int) $row['notifications_enabled'] ? 'Enabled' : 'Disabled') . '</td><td><code>' . esc_html($masked) . '</code></td><td>' . esc_html((string) $row['last_seen']) . '</td><td><a class="button button-small" href="' . esc_url($send_url) . '">Send</a></td></tr>';
        }
        echo '</tbody></table>';
    }

    private static function render_history_tab(): void {
        global $wpdb;
        $table = self::notifications_table();
        $rows = $wpdb->get_results("SELECT * FROM {$table} ORDER BY id DESC LIMIT 150", ARRAY_A);
        echo '<h2>Notification history & schedule</h2>';
        echo '<p><strong>Accepted</strong> means Firebase accepted the send request; it is not a read receipt or guaranteed-device delivery confirmation.</p>';
        if (!$rows) { echo '<p>No notification history yet.</p>'; return; }

        echo '<table class="widefat striped"><thead><tr><th>ID</th><th>Message</th><th>Audience</th><th>Language</th><th>Status</th><th>Targets</th><th>When (UTC)</th><th>Result</th><th></th></tr></thead><tbody>';
        foreach ($rows as $row) {
            $when = $row['scheduled_at'] ?: ($row['sent_at'] ?: $row['created_at']);
            $audience = self::audience_label((string) $row['audience'], (int) $row['device_id']);
            $result = '';
            if ((int) $row['accepted_count'] > 0) $result .= 'Accepted: ' . (int) $row['accepted_count'];
            if ((int) $row['failed_count'] > 0) $result .= ($result ? ' · ' : '') . 'Failed: ' . (int) $row['failed_count'];
            if (!empty($row['last_error'])) $result .= ($result ? '<br>' : '') . '<span style="color:#b32d2e">' . esc_html((string) $row['last_error']) . '</span>';
            if ($result === '') $result = '—';

            echo '<tr><td>#' . esc_html((string) $row['id']) . '</td><td><strong>' . esc_html((string) $row['title']) . '</strong><br><span style="color:#646970">' . esc_html(wp_trim_words((string) $row['body'], 16, '…')) . '</span></td><td>' . esc_html($audience) . '</td><td>' . esc_html($row['locale'] ? strtoupper((string) $row['locale']) : 'ALL') . '</td><td><strong>' . esc_html((string) $row['status']) . '</strong></td><td>' . esc_html((string) $row['target_count']) . '</td><td>' . esc_html((string) $when) . '</td><td>' . $result . '</td><td>';
            if ($row['status'] === 'scheduled') {
                $cancel_url = wp_nonce_url(admin_url('admin-post.php?action=tapbix_push_cancel&notification_id=' . (int) $row['id']), 'tapbix_push_cancel_' . (int) $row['id']);
                echo '<a class="button button-small" href="' . esc_url($cancel_url) . '">Cancel</a>';
            }
            echo '</td></tr>';
        }
        echo '</tbody></table>';
    }

    private static function audience_label(string $audience, int $device_id): string {
        if ($audience === 'device') return 'Device #' . $device_id;
        if ($audience === 'android') return 'Android';
        if ($audience === 'ios') return 'iPhone / iPad';
        return 'All mobile';
    }

    private static function render_settings_tab(): void {
        $account = self::get_service_account();
        $configured = $account !== null;
        echo '<div class="card" style="max-width:760px;padding:22px"><h2 style="margin-top:0">Firebase Cloud Messaging</h2>';
        if ($configured) {
            echo '<p><strong>Status:</strong> Configured</p><p><strong>Project:</strong> <code>' . esc_html((string) $account['project_id']) . '</code></p><p><strong>Service account:</strong> <code>' . esc_html((string) $account['client_email']) . '</code></p>';
        } else echo '<p><strong>Status:</strong> Not configured</p>';
        echo '<p>The Firebase key belongs only to this notifications plugin and is never sent to the TapBix app.</p><form method="post" action="' . esc_url(admin_url('admin-post.php')) . '">';
        wp_nonce_field('tapbix_push_save_settings');
        echo '<input type="hidden" name="action" value="tapbix_push_save_settings"><textarea name="service_account_json" class="large-text code" rows="12" spellcheck="false" placeholder="{ &quot;type&quot;: &quot;service_account&quot;, ... }"></textarea><p class="description">Leave blank to keep the current key.</p>';
        if ($configured) echo '<p><label><input type="checkbox" name="remove_credentials" value="1"> Remove the currently stored Firebase credentials</label></p>';
        submit_button('Save Firebase Settings');
        echo '</form></div>';
    }

    public static function handle_save_settings(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized.');
        check_admin_referer('tapbix_push_save_settings');
        $user_id = get_current_user_id();

        if (!empty($_POST['remove_credentials'])) {
            delete_option(self::OPTION_SERVICE_ACCOUNT);
            self::clear_access_token_cache();
            self::set_notice($user_id, true, 'Firebase credentials removed.');
            self::redirect_to_tab('settings');
        }

        $raw = isset($_POST['service_account_json']) ? trim(wp_unslash($_POST['service_account_json'])) : '';
        if ($raw === '') {
            self::set_notice($user_id, true, 'No changes were made.');
            self::redirect_to_tab('settings');
        }

        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) {
            self::set_notice($user_id, false, 'The service-account JSON is not valid JSON.');
            self::redirect_to_tab('settings');
        }
        foreach (['project_id', 'client_email', 'private_key'] as $required) {
            if (empty($decoded[$required]) || !is_string($decoded[$required])) {
                self::set_notice($user_id, false, 'The service-account JSON is missing: ' . $required);
                self::redirect_to_tab('settings');
            }
        }
        if ($decoded['project_id'] !== self::EXPECTED_FIREBASE_PROJECT) {
            self::set_notice($user_id, false, 'Wrong Firebase project. Expected ' . self::EXPECTED_FIREBASE_PROJECT . '.');
            self::redirect_to_tab('settings');
        }
        if (strpos($decoded['private_key'], 'BEGIN PRIVATE KEY') === false) {
            self::set_notice($user_id, false, 'The Firebase private key is invalid.');
            self::redirect_to_tab('settings');
        }

        $safe_account = [
            'project_id' => sanitize_text_field($decoded['project_id']),
            'client_email' => sanitize_email($decoded['client_email']),
            'private_key' => $decoded['private_key'],
            'token_uri' => !empty($decoded['token_uri']) && is_string($decoded['token_uri']) ? esc_url_raw($decoded['token_uri']) : 'https://oauth2.googleapis.com/token',
        ];
        update_option(self::OPTION_SERVICE_ACCOUNT, wp_json_encode($safe_account), false);
        self::clear_access_token_cache();
        self::set_notice($user_id, true, 'Firebase credentials saved.');
        self::redirect_to_tab('settings');
    }

    public static function handle_send(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized.');
        check_admin_referer('tapbix_push_send');

        $title = substr(sanitize_text_field(wp_unslash($_POST['title'] ?? '')), 0, 100);
        $body = substr(sanitize_textarea_field(wp_unslash($_POST['body'] ?? '')), 0, 500);
        $audience = sanitize_key(wp_unslash($_POST['audience'] ?? 'all'));
        if (!in_array($audience, ['all', 'android', 'ios', 'device'], true)) $audience = 'all';
        $locale = isset($_POST['locale']) && $_POST['locale'] !== '' ? self::normalize_locale((string) wp_unslash($_POST['locale'])) : '';
        $device_id = $audience === 'device' ? absint($_POST['device_id'] ?? 0) : 0;
        $validate_only = !empty($_POST['validate_only']);
        $delivery = sanitize_key(wp_unslash($_POST['delivery'] ?? 'now'));

        if ($title === '' || $body === '') {
            self::set_notice(get_current_user_id(), false, 'Title and message are required.');
            self::redirect_to_tab('send');
        }
        if ($audience === 'device' && !$device_id) {
            self::set_notice(get_current_user_id(), false, 'Choose a device.');
            self::redirect_to_tab('send');
        }

        $scheduled_at = null;
        $scheduled_timestamp = 0;
        if (!$validate_only && $delivery === 'schedule') {
            $raw_schedule = sanitize_text_field(wp_unslash($_POST['schedule_at'] ?? ''));
            $local_dt = DateTimeImmutable::createFromFormat('Y-m-d\TH:i', $raw_schedule, wp_timezone());
            if (!$local_dt) {
                self::set_notice(get_current_user_id(), false, 'Choose a valid schedule date and time.');
                self::redirect_to_tab('send');
            }
            $utc_dt = $local_dt->setTimezone(new DateTimeZone('UTC'));
            $scheduled_timestamp = $utc_dt->getTimestamp();
            if ($scheduled_timestamp <= time() + 30) {
                self::set_notice(get_current_user_id(), false, 'Scheduled time must be in the future.');
                self::redirect_to_tab('send');
            }
            $scheduled_at = $utc_dt->format('Y-m-d H:i:s');
        }

        global $wpdb;
        $table = self::notifications_table();
        $now = current_time('mysql', true);
        $status = $scheduled_at ? 'scheduled' : 'sending';
        $inserted = $wpdb->insert($table, [
            'title' => $title,
            'body' => $body,
            'audience' => $audience,
            'locale' => $audience === 'device' ? '' : $locale,
            'device_id' => $device_id ?: null,
            'validate_only' => $validate_only ? 1 : 0,
            'status' => $status,
            'scheduled_at' => $scheduled_at,
            'created_by' => get_current_user_id(),
            'created_at' => $now,
            'updated_at' => $now,
        ], ['%s','%s','%s','%s','%d','%d','%s','%s','%d','%s','%s']);

        if (!$inserted) {
            self::set_notice(get_current_user_id(), false, 'Unable to save this notification.');
            self::redirect_to_tab('send');
        }
        $notification_id = (int) $wpdb->insert_id;

        if ($scheduled_at) {
            wp_schedule_single_event($scheduled_timestamp, self::SINGLE_HOOK, [$notification_id]);
            self::set_notice(get_current_user_id(), true, 'Notification scheduled successfully.');
            self::redirect_to_tab('history');
        }

        $result = self::dispatch_notification($notification_id);
        if (is_wp_error($result)) {
            self::set_notice(get_current_user_id(), false, 'Firebase error: ' . $result->get_error_message());
        } else {
            self::set_notice(get_current_user_id(), true, $validate_only ? 'Firebase accepted the message as valid. Nothing was delivered.' : 'Notification accepted by Firebase for delivery.');
        }
        self::redirect_to_tab('history');
    }

    public static function handle_cancel(): void {
        if (!current_user_can('manage_options')) wp_die('Unauthorized.');
        $id = absint($_GET['notification_id'] ?? 0);
        check_admin_referer('tapbix_push_cancel_' . $id);
        global $wpdb;
        $table = self::notifications_table();
        $row = $wpdb->get_row($wpdb->prepare("SELECT id, status, scheduled_at FROM {$table} WHERE id = %d", $id), ARRAY_A);
        if (!$row || $row['status'] !== 'scheduled') {
            self::set_notice(get_current_user_id(), false, 'This notification is not scheduled.');
            self::redirect_to_tab('history');
        }
        $wpdb->update($table, ['status' => 'cancelled', 'updated_at' => current_time('mysql', true)], ['id' => $id], ['%s','%s'], ['%d']);
        if (!empty($row['scheduled_at'])) {
            $timestamp = strtotime((string) $row['scheduled_at'] . ' UTC');
            if ($timestamp) wp_unschedule_event($timestamp, self::SINGLE_HOOK, [$id]);
        }
        self::set_notice(get_current_user_id(), true, 'Scheduled notification cancelled.');
        self::redirect_to_tab('history');
    }

    public static function run_scheduled_notification(int $notification_id): void {
        global $wpdb;
        $table = self::notifications_table();
        $status = $wpdb->get_var($wpdb->prepare("SELECT status FROM {$table} WHERE id = %d", $notification_id));
        if ($status !== 'scheduled') return;
        $wpdb->update($table, ['status' => 'sending', 'updated_at' => current_time('mysql', true)], ['id' => $notification_id], ['%s','%s'], ['%d']);
        self::dispatch_notification($notification_id);
    }

    public static function process_queue(): void {
        global $wpdb;
        $table = self::notifications_table();
        $now = current_time('mysql', true);
        $ids = $wpdb->get_col($wpdb->prepare("SELECT id FROM {$table} WHERE status = 'scheduled' AND scheduled_at IS NOT NULL AND scheduled_at <= %s ORDER BY scheduled_at ASC LIMIT 20", $now));
        foreach ($ids as $id) self::run_scheduled_notification((int) $id);
    }

    private static function dispatch_notification(int $notification_id) {
        global $wpdb;
        $notifications = self::notifications_table();
        $devices = self::devices_table();
        $row = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$notifications} WHERE id = %d", $notification_id), ARRAY_A);
        if (!$row) return new WP_Error('tapbix_push_missing_notification', 'Notification record not found.');
        if (!in_array($row['status'], ['sending', 'scheduled'], true)) return new WP_Error('tapbix_push_bad_status', 'Notification is not ready to send.');

        $where = "notifications_enabled = 1";
        $params = [];
        if ($row['audience'] === 'android' || $row['audience'] === 'ios') {
            $where .= " AND platform = %s";
            $params[] = $row['audience'];
        }
        if (!empty($row['locale'])) {
            $where .= " AND locale = %s";
            $params[] = $row['locale'];
        }
        if ($row['audience'] === 'device') {
            $where .= " AND id = %d";
            $params[] = (int) $row['device_id'];
        }
        $count_sql = "SELECT COUNT(*) FROM {$devices} WHERE {$where}";
        $target_count = $params ? (int) $wpdb->get_var($wpdb->prepare($count_sql, ...$params)) : (int) $wpdb->get_var($count_sql);

        $target = [];
        if ($row['audience'] === 'device') {
            $token = $wpdb->get_var($wpdb->prepare("SELECT fcm_token FROM {$devices} WHERE id = %d AND notifications_enabled = 1", (int) $row['device_id']));
            if (!$token) {
                $error = new WP_Error('tapbix_push_device_missing', 'The selected device is not available for notifications.');
                self::mark_failed($notification_id, $target_count, $error->get_error_message());
                return $error;
            }
            $target['token'] = (string) $token;
        } else {
            $platform_topic = $row['audience'] === 'android' ? 'tapbix_android' : ($row['audience'] === 'ios' ? 'tapbix_ios' : 'tapbix_all');
            if (!empty($row['locale'])) {
                $language_topic = 'tapbix_lang_' . $row['locale'];
                if ($row['audience'] === 'all') {
                    $target['topic'] = $language_topic;
                } else {
                    $target['condition'] = "'{$platform_topic}' in topics && '{$language_topic}' in topics";
                }
            } else {
                $target['topic'] = $platform_topic;
            }
        }

        $result = self::send_fcm_message($target, (string) $row['title'], (string) $row['body'], (bool) $row['validate_only'], $notification_id);
        if (is_wp_error($result)) {
            self::mark_failed($notification_id, $target_count, $result->get_error_message());
            return $result;
        }

        $status = (bool) $row['validate_only'] ? 'validated' : 'sent';
        $accepted = $target_count > 0 ? $target_count : 1;
        $wpdb->update($notifications, [
            'status' => $status,
            'sent_at' => current_time('mysql', true),
            'target_count' => $target_count,
            'accepted_count' => $accepted,
            'failed_count' => 0,
            'firebase_name' => (string) ($result['name'] ?? ''),
            'last_error' => null,
            'updated_at' => current_time('mysql', true),
        ], ['id' => $notification_id], ['%s','%s','%d','%d','%d','%s','%s','%s'], ['%d']);
        return true;
    }

    private static function mark_failed(int $id, int $target_count, string $message): void {
        global $wpdb;
        $wpdb->update(self::notifications_table(), [
            'status' => 'failed',
            'sent_at' => current_time('mysql', true),
            'target_count' => $target_count,
            'accepted_count' => 0,
            'failed_count' => max(1, $target_count),
            'last_error' => substr($message, 0, 2000),
            'updated_at' => current_time('mysql', true),
        ], ['id' => $id], ['%s','%s','%d','%d','%d','%s','%s'], ['%d']);
    }

    private static function send_fcm_message(array $target, string $title, string $body, bool $validate_only, int $notification_id) {
        $account = self::get_service_account();
        if ($account === null) return new WP_Error('tapbix_push_not_configured', 'Firebase credentials are not configured.');
        $access_token = self::get_access_token($account);
        if (is_wp_error($access_token)) return $access_token;

        $message = [
            'notification' => ['title' => $title, 'body' => $body],
            'data' => [
                'tapbix_action' => 'open_app',
                'tapbix_source' => 'wordpress',
                'tapbix_notification_id' => (string) $notification_id,
            ],
            'android' => [
                'priority' => 'high',
                'notification' => ['channel_id' => 'tapbix_general', 'sound' => 'default'],
            ],
            'apns' => [
                'headers' => ['apns-priority' => '10'],
                'payload' => ['aps' => ['sound' => 'default']],
            ],
        ];
        foreach (['topic', 'condition', 'token'] as $key) {
            if (!empty($target[$key])) { $message[$key] = $target[$key]; break; }
        }
        $payload = ['validate_only' => $validate_only, 'message' => $message];
        $endpoint = sprintf('https://fcm.googleapis.com/v1/projects/%s/messages:send', rawurlencode($account['project_id']));
        $response = wp_remote_post($endpoint, [
            'timeout' => 25,
            'headers' => ['Authorization' => 'Bearer ' . $access_token, 'Content-Type' => 'application/json; charset=utf-8'],
            'body' => wp_json_encode($payload),
        ]);
        if (is_wp_error($response)) return $response;

        $code = (int) wp_remote_retrieve_response_code($response);
        $response_body = wp_remote_retrieve_body($response);
        $decoded = json_decode($response_body, true);
        if ($code < 200 || $code >= 300) {
            $message_text = is_array($decoded) && isset($decoded['error']['message']) ? sanitize_text_field((string) $decoded['error']['message']) : 'FCM returned HTTP ' . $code;
            return new WP_Error('tapbix_push_fcm_error', $message_text);
        }
        return is_array($decoded) ? $decoded : [];
    }

    private static function get_service_account(): ?array {
        $raw = get_option(self::OPTION_SERVICE_ACCOUNT, '');
        if (!is_string($raw) || $raw === '') return null;
        $decoded = json_decode($raw, true);
        if (!is_array($decoded)) return null;
        foreach (['project_id', 'client_email', 'private_key', 'token_uri'] as $key) {
            if (empty($decoded[$key]) || !is_string($decoded[$key])) return null;
        }
        return $decoded;
    }

    private static function get_access_token(array $account) {
        $cache_key = 'tapbix_push_oauth_' . md5($account['client_email']);
        $cached = get_transient($cache_key);
        if (is_string($cached) && $cached !== '') return $cached;

        $now = time();
        $header = ['alg' => 'RS256', 'typ' => 'JWT'];
        $claims = ['iss' => $account['client_email'], 'scope' => self::ACCESS_TOKEN_SCOPE, 'aud' => $account['token_uri'], 'iat' => $now, 'exp' => $now + 3600];
        $unsigned = self::base64url(wp_json_encode($header)) . '.' . self::base64url(wp_json_encode($claims));
        $private_key = openssl_pkey_get_private($account['private_key']);
        if ($private_key === false) return new WP_Error('tapbix_push_private_key', 'Unable to read the Firebase private key.');
        $signature = '';
        if (!openssl_sign($unsigned, $signature, $private_key, OPENSSL_ALGO_SHA256)) return new WP_Error('tapbix_push_jwt_sign', 'Unable to sign the Firebase authorization request.');
        $jwt = $unsigned . '.' . self::base64url($signature);

        $response = wp_remote_post($account['token_uri'], ['timeout' => 20, 'body' => ['grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer', 'assertion' => $jwt]]);
        if (is_wp_error($response)) return $response;
        $code = (int) wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        if ($code < 200 || $code >= 300 || !is_array($body) || empty($body['access_token'])) {
            $error = is_array($body) && !empty($body['error_description']) ? sanitize_text_field((string) $body['error_description']) : 'Google OAuth returned HTTP ' . $code;
            return new WP_Error('tapbix_push_oauth_error', $error);
        }
        $token = (string) $body['access_token'];
        $expires_in = isset($body['expires_in']) ? max(300, (int) $body['expires_in'] - 120) : 3300;
        set_transient($cache_key, $token, $expires_in);
        return $token;
    }

    private static function clear_access_token_cache(): void {
        $account = self::get_service_account();
        if ($account !== null) delete_transient('tapbix_push_oauth_' . md5($account['client_email']));
    }

    private static function base64url(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    private static function set_notice(int $user_id, bool $success, string $message): void {
        set_transient('tapbix_push_notice_' . $user_id, ['success' => $success, 'message' => $message], 5 * MINUTE_IN_SECONDS);
    }

    private static function redirect_to_tab(string $tab): void {
        wp_safe_redirect(add_query_arg(['page' => 'tapbix-notifications', 'tab' => $tab], admin_url('admin.php')));
        exit;
    }
}

register_activation_hook(__FILE__, [TapBix_Notifications_Plugin::class, 'activate']);
register_deactivation_hook(__FILE__, [TapBix_Notifications_Plugin::class, 'deactivate']);
TapBix_Notifications_Plugin::init();
