TapBix Notifications 0.2.0

Standalone push-notification system for TapBix.
It does not read, modify, or depend on TapBix licensing, subscriptions, WooCommerce orders, or RevenueCat.

0.2.0 adds:
- Notification history
- Send to one specific device
- Scheduling and cancellation
- Arabic / English / French targeting
- Combined platform + language targeting
- Better device-token deduplication by install ID
- Existing Firebase credentials are preserved during upgrade
