TapBix Notifications 0.2.2

Standalone push notification control center for TapBix.

Changes in 0.2.2:
- Keeps the 0.2.1 no-targets history accuracy fix.
- Adds checkboxes to History & Schedule.
- Adds Delete selected.
- Adds per-row Delete.
- Deleting a scheduled item also clears its scheduled WordPress event.
- History deletion never touches notification devices, Firebase credentials, licensing, subscriptions, WooCommerce, or RevenueCat.
